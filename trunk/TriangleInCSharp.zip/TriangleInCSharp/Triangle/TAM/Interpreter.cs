﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Tools.TAM
{
    public class Interpreter
    {
        static string objectName;

        // DATA STORE
        static int[] data = new int[1024];

        // DATA STORE REGISTERS AND OTHER REGISTERS
        public enum DataStoreRegister
        {
            CB = 0,
            SB = 0,
            HB = 1024  // = upper bound of data array + 1
        }

        static int
          CT, CP, ST, HT, LB, status;

        // status values
        public enum StatusValue
        {
            running = 0,
            halted = 1,
            failedDataStoreFull = 2,
            failedInvalidCodeAddress = 3,
            failedInvalidInstruction = 4,
            failedOverflow = 5,
            failedZeroDivide = 6,
            failedIOError = 7
        }

        static long accumulator;

        static int Content(Machine.RegisterNumber r)
        {
            // Returns the current content of register r,
            // even if r is one of the pseudo-registers L1..L6.

            switch (r)
            {
                case Machine.RegisterNumber.CBr:
                    return (int)DataStoreRegister.CB;
                case Machine.RegisterNumber.CTr:
                    return CT;
                case Machine.RegisterNumber.PBr:
                    return (int)Machine.CodeStoreRegister.PB;
                case Machine.RegisterNumber.PTr:
                    return (int)Machine.CodeStoreRegister.PT;
                case Machine.RegisterNumber.SBr:
                    return (int)DataStoreRegister.SB;
                case Machine.RegisterNumber.STr:
                    return ST;
                case Machine.RegisterNumber.HBr:
                    return (int)DataStoreRegister.HB;
                case Machine.RegisterNumber.HTr:
                    return HT;
                case Machine.RegisterNumber.LBr:
                    return LB;
                case Machine.RegisterNumber.L1r:
                    return data[LB];
                case Machine.RegisterNumber.L2r:
                    return data[data[LB]];
                case Machine.RegisterNumber.L3r:
                    return data[data[data[LB]]];
                case Machine.RegisterNumber.L4r:
                    return data[data[data[data[LB]]]];
                case Machine.RegisterNumber.L5r:
                    return data[data[data[data[data[LB]]]]];
                case Machine.RegisterNumber.L6r:
                    return data[data[data[data[data[data[LB]]]]]];
                case Machine.RegisterNumber.CPr:
                    return CP;
                default:
                    return 0;
            }
        }

        // PROGRAM STATUS
        static void Dump()
        {
            // Writes a summary of the machine state.
            int
              addr, staticLink, dynamicLink,
              localRegNum;

            Console.WriteLine("");
            Console.WriteLine("State of data store and registers:");
            Console.WriteLine("");
            if (HT == (int)DataStoreRegister.HB)
                Console.WriteLine("            |--------|          (heap is empty)");
            else
            {
                Console.WriteLine("       HB-->");
                Console.WriteLine("            |--------|");
                for (addr = (int)DataStoreRegister.HB - 1; addr >= HT; addr--)
                {
                    Console.Write(addr + ":");
                    if (addr == HT)
                        Console.Write(" HT-->");
                    else
                        Console.Write("      ");
                    Console.WriteLine("|" + data[addr] + "|");
                }
                Console.WriteLine("            |--------|");
            }
            Console.WriteLine("            |////////|");
            Console.WriteLine("            |////////|");
            if (ST == (int)DataStoreRegister.SB)
                Console.WriteLine("            |--------|          (stack is empty)");
            else
            {
                dynamicLink = LB;
                staticLink = LB;
                localRegNum = (int)Machine.RegisterNumber.LBr;
                Console.WriteLine("      ST--> |////////|");
                Console.WriteLine("            |--------|");
                for (addr = ST - 1; addr >= (int)DataStoreRegister.SB; addr--)
                {
                    Console.Write(addr + ":");
                    if (addr == (int)DataStoreRegister.SB)
                        Console.Write(" SB-->");
                    else if (addr == staticLink)
                    {
                        switch ((Machine.RegisterNumber)localRegNum)
                        {
                            case Machine.RegisterNumber.LBr:
                                Console.Write(" LB-->");
                                break;
                            case Machine.RegisterNumber.L1r:
                                Console.Write(" L1-->");
                                break;
                            case Machine.RegisterNumber.L2r:
                                Console.Write(" L2-->");
                                break;
                            case Machine.RegisterNumber.L3r:
                                Console.Write(" L3-->");
                                break;
                            case Machine.RegisterNumber.L4r:
                                Console.Write(" L4-->");
                                break;
                            case Machine.RegisterNumber.L5r:
                                Console.Write(" L5-->");
                                break;
                            case Machine.RegisterNumber.L6r:
                                Console.Write(" L6-->");
                                break;
                        }
                        staticLink = data[addr];
                        localRegNum = localRegNum + 1;
                    }
                    else
                        Console.Write("      ");
                    if ((addr == dynamicLink) && (dynamicLink != (int)DataStoreRegister.SB))
                        Console.Write("|SL=" + data[addr] + "|");
                    else if ((addr == dynamicLink + 1) && (dynamicLink != (int)DataStoreRegister.SB))
                        Console.Write("|DL=" + data[addr] + "|");
                    else if ((addr == dynamicLink + 2) && (dynamicLink != (int)DataStoreRegister.SB))
                        Console.Write("|RA=" + data[addr] + "|");
                    else
                        Console.Write("|" + data[addr] + "|");
                    Console.WriteLine("");
                    if (addr == dynamicLink)
                    {
                        Console.WriteLine("            |--------|");
                        dynamicLink = data[addr + 1];
                    }
                }
            }
            Console.WriteLine("");
        }

        static void ShowStatus()
        {
            // Writes an indication of whether and why the program has terminated.
            Console.WriteLine("");
            switch ((StatusValue)status)
            {
                case StatusValue.running:
                    Console.WriteLine("Program is running.");
                    break;
                case StatusValue.halted:
                    Console.WriteLine("Program has halted normally.");
                    break;
                case StatusValue.failedDataStoreFull:
                    Console.WriteLine("Program has failed due to exhaustion of Data Store.");
                    break;
                case StatusValue.failedInvalidCodeAddress:
                    Console.WriteLine("Program has failed due to an invalid code address.");
                    break;
                case StatusValue.failedInvalidInstruction:
                    Console.WriteLine("Program has failed due to an invalid instruction.");
                    break;
                case StatusValue.failedOverflow:
                    Console.WriteLine("Program has failed due to overflow.");
                    break;
                case StatusValue.failedZeroDivide:
                    Console.WriteLine("Program has failed due to division by zero.");
                    break;
                case StatusValue.failedIOError:
                    Console.WriteLine("Program has failed due to an IO error.");
                    break;
            }
            if (status != (int)StatusValue.halted)
                Dump();
        }


        // INTERPRETATION

        static void CheckSpace(int spaceNeeded)
        {
            // Signals failure if there is not enough space to expand the stack or
            // heap by spaceNeeded.

            if (HT - ST < spaceNeeded)
                status = (int)StatusValue.failedDataStoreFull;
        }

        static bool IsTrue(int datum)
        {
            // Tests whether the given datum represents true.
            return (datum == (int)Machine.DataRepresentation.trueRep);
        }

        static bool Equal(int size, int addr1, int addr2)
        {
            // Tests whether two multi-word objects are equal, given their common
            // size and their base addresses.

            bool eq;
            int index;

            eq = true;
            index = 0;
            while (eq && (index < size))
                if (data[addr1 + index] == data[addr2 + index])
                    index = index + 1;
                else
                    eq = false;
            return eq;
        }

        static int OverflowChecked(long datum)
        {
            // Signals failure if the datum is too large to fit into a single word,
            // otherwise returns the datum as a single word.

            if ((-(int)Machine.DataRepresentation.maxintRep <= datum) && (datum <= (int)Machine.DataRepresentation.maxintRep))
                return (int)datum;
            else
            {
                status = (int)StatusValue.failedOverflow;
                return 0;
            }
        }

        static int ToInt(bool b)
        {
            return b ? (int)Machine.DataRepresentation.trueRep : (int)Machine.DataRepresentation.falseRep;
        }

        static int currentChar;

        static int ReadInt()
        {
            int temp = 0;
            int sign = 1;

            do
            {
                currentChar = Console.Read();
            } while (Char.IsWhiteSpace((char)currentChar));

            if ((currentChar == '-') || (currentChar == '+'))
                do
                {
                    sign = (currentChar == '-') ? -1 : 1;
                    currentChar = Console.Read();
                } while ((currentChar == '-') || currentChar == '+');

            if (Char.IsDigit((char)currentChar))
                do
                {
                    temp = temp * 10 + (currentChar - '0');
                    currentChar = Console.Read();
                } while (Char.IsDigit((char)currentChar));

            return sign * temp;
        }

        static void CallPrimitive(Machine.PrimitiveRoutine primitiveDisplacement)
        {
            // Invokes the given primitive routine.

            int addr, size;
            char ch;

            switch (primitiveDisplacement)
            {
                case Machine.PrimitiveRoutine.idDisplacement:
                    break; // nothing to be done
                case Machine.PrimitiveRoutine.notDisplacement:
                    data[ST - 1] = ToInt(!IsTrue(data[ST - 1]));
                    break;
                case Machine.PrimitiveRoutine.andDisplacement:
                    ST = ST - 1;
                    data[ST - 1] = ToInt(IsTrue(data[ST - 1]) & IsTrue(data[ST]));
                    break;
                case Machine.PrimitiveRoutine.orDisplacement:
                    ST = ST - 1;
                    data[ST - 1] = ToInt(IsTrue(data[ST - 1]) | IsTrue(data[ST]));
                    break;
                case Machine.PrimitiveRoutine.succDisplacement:
                    data[ST - 1] = OverflowChecked(data[ST - 1] + 1);
                    break;
                case Machine.PrimitiveRoutine.predDisplacement:
                    data[ST - 1] = OverflowChecked(data[ST - 1] - 1);
                    break;
                case Machine.PrimitiveRoutine.negDisplacement:
                    data[ST - 1] = -data[ST - 1];
                    break;
                case Machine.PrimitiveRoutine.addDisplacement:
                    ST = ST - 1;
                    accumulator = data[ST - 1];
                    data[ST - 1] = OverflowChecked(accumulator + data[ST]);
                    break;
                case Machine.PrimitiveRoutine.subDisplacement:
                    ST = ST - 1;
                    accumulator = data[ST - 1];
                    data[ST - 1] = OverflowChecked(accumulator - data[ST]);
                    break;
                case Machine.PrimitiveRoutine.multDisplacement:
                    ST = ST - 1;
                    accumulator = data[ST - 1];
                    data[ST - 1] = OverflowChecked(accumulator * data[ST]);
                    break;
                case Machine.PrimitiveRoutine.divDisplacement:
                    ST = ST - 1;
                    accumulator = data[ST - 1];
                    if (data[ST] != 0)
                        data[ST - 1] = (int)(accumulator / data[ST]);
                    else
                        status = (int)StatusValue.failedZeroDivide;
                    break;
                case Machine.PrimitiveRoutine.modDisplacement:
                    ST = ST - 1;
                    accumulator = data[ST - 1];
                    if (data[ST] != 0)
                        data[ST - 1] = (int)(accumulator % data[ST]);
                    else
                        status = (int)StatusValue.failedZeroDivide;
                    break;
                case Machine.PrimitiveRoutine.ltDisplacement:
                    ST = ST - 1;
                    data[ST - 1] = ToInt(data[ST - 1] < data[ST]);
                    break;
                case Machine.PrimitiveRoutine.leDisplacement:
                    ST = ST - 1;
                    data[ST - 1] = ToInt(data[ST - 1] <= data[ST]);
                    break;
                case Machine.PrimitiveRoutine.geDisplacement:
                    ST = ST - 1;
                    data[ST - 1] = ToInt(data[ST - 1] >= data[ST]);
                    break;
                case Machine.PrimitiveRoutine.gtDisplacement:
                    ST = ST - 1;
                    data[ST - 1] = ToInt(data[ST - 1] > data[ST]);
                    break;
                case Machine.PrimitiveRoutine.eqDisplacement:
                    size = data[ST - 1]; // size of each comparand
                    ST = ST - 2 * size;
                    data[ST - 1] = ToInt(Equal(size, ST - 1, ST - 1 + size));
                    break;
                case Machine.PrimitiveRoutine.neDisplacement:
                    size = data[ST - 1]; // size of each comparand
                    ST = ST - 2 * size;
                    data[ST - 1] = ToInt(!Equal(size, ST - 1, ST - 1 + size));
                    break;
                case Machine.PrimitiveRoutine.eolDisplacement:
                    data[ST] = ToInt(currentChar == '\n');
                    ST = ST + 1;
                    break;
                case Machine.PrimitiveRoutine.eofDisplacement:
                    data[ST] = ToInt(currentChar == -1);
                    ST = ST + 1;
                    break;
                case Machine.PrimitiveRoutine.getDisplacement:
                    ST = ST - 1;
                    addr = data[ST];
                    try
                    {
                        currentChar = Console.Read();
                    }
                    catch (IOException s)
                    {
                        status = (int)StatusValue.failedIOError;
                    }
                    data[addr] = (int)currentChar;
                    break;
                case Machine.PrimitiveRoutine.putDisplacement:
                    ST = ST - 1;
                    ch = (char)data[ST];
                    Console.Write(ch);
                    break;
                case Machine.PrimitiveRoutine.geteolDisplacement:
                    try
                    {
                        while ((currentChar = Console.Read()) != '\n') ;
                    }
                    catch (IOException s)
                    {
                        status = (int)StatusValue.failedIOError;
                    }
                    break;
                case Machine.PrimitiveRoutine.puteolDisplacement:
                    Console.WriteLine("");
                    break;
                case Machine.PrimitiveRoutine.getintDisplacement:
                    ST = ST - 1;
                    addr = data[ST];
                    try
                    {
                        accumulator = ReadInt();
                    }
                    catch (IOException s)
                    {
                        status = (int)StatusValue.failedIOError;
                    }
                    data[addr] = (int)accumulator;
                    break;
                case Machine.PrimitiveRoutine.putintDisplacement:
                    ST = ST - 1;
                    accumulator = data[ST];
                    Console.Write(accumulator);
                    break;
                case Machine.PrimitiveRoutine.newDisplacement:
                    size = data[ST - 1];
                    CheckSpace(size);
                    HT = HT - size;
                    data[ST - 1] = HT;
                    break;
                case Machine.PrimitiveRoutine.disposeDisplacement:
                    ST = ST - 1; // no action taken at present
                    break;
            }
        }

        static void InterpretProgram()
        {
            // Runs the program in code store.

            Instruction currentInstr;
            int op, r, n, d, addr, index;

            // Initialize registers ...
            ST = (int)DataStoreRegister.SB;
            HT = (int)DataStoreRegister.HB;
            LB = (int)DataStoreRegister.SB;
            CP = (int)DataStoreRegister.CB;
            status = (int)StatusValue.running;
            do
            {
                // Fetch instruction ...
                currentInstr = Machine.code[CP];
                // Decode instruction ...
                op = currentInstr.op;
                r = currentInstr.r;
                n = currentInstr.n;
                d = currentInstr.d;
                // Execute instruction ...
                switch ((Machine.Opcode)op)
                {
                    case Machine.Opcode.LOADop:
                        addr = d + Content((Machine.RegisterNumber)r);
                        CheckSpace(n);
                        for (index = 0; index < n; index++)
                            data[ST + index] = data[addr + index];
                        ST = ST + n;
                        CP = CP + 1;
                        break;
                    case Machine.Opcode.LOADAop:
                        addr = d + Content((Machine.RegisterNumber)r);
                        CheckSpace(1);
                        data[ST] = addr;
                        ST = ST + 1;
                        CP = CP + 1;
                        break;
                    case Machine.Opcode.LOADIop:
                        ST = ST - 1;
                        addr = data[ST];
                        CheckSpace(n);
                        for (index = 0; index < n; index++)
                            data[ST + index] = data[addr + index];
                        ST = ST + n;
                        CP = CP + 1;
                        break;
                    case Machine.Opcode.LOADLop:
                        CheckSpace(1);
                        data[ST] = d;
                        ST = ST + 1;
                        CP = CP + 1;
                        break;
                    case Machine.Opcode.STOREop:
                        addr = d + Content((Machine.RegisterNumber)r);
                        ST = ST - n;
                        for (index = 0; index < n; index++)
                            data[addr + index] = data[ST + index];
                        CP = CP + 1;
                        break;
                    case Machine.Opcode.STOREIop:
                        ST = ST - 1;
                        addr = data[ST];
                        ST = ST - n;
                        for (index = 0; index < n; index++)
                            data[addr + index] = data[ST + index];
                        CP = CP + 1;
                        break;
                    case Machine.Opcode.CALLop:
                        addr = d + Content((Machine.RegisterNumber)r);
                        if (addr >= (int)Machine.CodeStoreRegister.PB)
                        {
                            CallPrimitive((Machine.PrimitiveRoutine)(addr - (int)Machine.CodeStoreRegister.PB));
                            CP = CP + 1;
                        }
                        else
                        {
                            CheckSpace(3);
                            if ((0 <= n) && (n <= 15))
                                data[ST] = Content((Machine.RegisterNumber)n); // static link
                            else
                                status = (int)StatusValue.failedInvalidInstruction;
                            data[ST + 1] = LB; // dynamic link
                            data[ST + 2] = CP + 1; // return address
                            LB = ST;
                            ST = ST + 3;
                            CP = addr;
                        }
                        break;
                    case Machine.Opcode.CALLIop:
                        ST = ST - 2;
                        addr = data[ST + 1];
                        if (addr >= (int)Machine.CodeStoreRegister.PB)
                        {
                            CallPrimitive((Machine.PrimitiveRoutine)(addr - (int)Machine.CodeStoreRegister.PB));
                            CP = CP + 1;
                        }
                        else
                        {
                            // data[ST] = static link already
                            data[ST + 1] = LB; // dynamic link
                            data[ST + 2] = CP + 1; // return address
                            LB = ST;
                            ST = ST + 3;
                            CP = addr;
                        }
                        break;
                    case Machine.Opcode.RETURNop:
                        addr = LB - d;
                        CP = data[LB + 2];
                        LB = data[LB + 1];
                        ST = ST - n;
                        for (index = 0; index < n; index++)
                            data[addr + index] = data[ST + index];
                        ST = addr + n;
                        break;
                    case Machine.Opcode.PUSHop:
                        CheckSpace(d);
                        ST = ST + d;
                        CP = CP + 1;
                        break;
                    case Machine.Opcode.POPop:
                        addr = ST - n - d;
                        ST = ST - n;
                        for (index = 0; index < n; index++)
                            data[addr + index] = data[ST + index];
                        ST = addr + n;
                        CP = CP + 1;
                        break;
                    case Machine.Opcode.JUMPop:
                        CP = d + Content((Machine.RegisterNumber)r);
                        break;
                    case Machine.Opcode.JUMPIop:
                        ST = ST - 1;
                        CP = data[ST];
                        break;
                    case Machine.Opcode.JUMPIFop:
                        ST = ST - 1;
                        if (data[ST] == n)
                            CP = d + Content((Machine.RegisterNumber)r);
                        else
                            CP = CP + 1;
                        break;
                    case Machine.Opcode.HALTop:
                        status = (int)StatusValue.halted;
                        break;
                }
                if ((CP < (int)DataStoreRegister.CB) || (CP >= CT))
                    status = (int)StatusValue.failedInvalidCodeAddress;
            } while (status == (int)StatusValue.running);
        }


        // LOADING

        static void LoadObjectProgram(String objectName)
        {
            // Loads the TAM object program into code store from the named file.

            FileStream objectFile = null;
            BinaryReader objectStream = null;

            int addr;
            bool finished = false;

            try
            {
                objectFile = new FileStream(objectName, FileMode.Open);
                objectStream = new BinaryReader(objectFile);

                addr = (int)Machine.CodeStoreRegister.CB;
                while (!finished)
                {
                    Machine.code[addr] = Instruction.Read(objectStream);
                    if (Machine.code[addr] == null)
                        finished = true;
                    else
                        addr = addr + 1;
                }
                CT = addr;
                objectFile.Close();
            }
            catch (FileNotFoundException s)
            {
                CT = (int)DataStoreRegister.CB;
                Console.Error.WriteLine("Error opening object file: " + s);
            }
            catch (IOException s)
            {
                CT = (int)DataStoreRegister.CB;
                Console.Error.WriteLine("Error reading object file: " + s);
            }
        }


        // RUNNING

        //public static void Main(String[] args)
        //{
        //    Console.WriteLine("********** TAM Interpreter (Java Version 2.1) **********");

        //    if (args.length == 1)
        //        objectName = args[0];
        //    else
        //        objectName = "obj.tam";

        //    loadObjectProgram(objectName);
        //    if (CT != CB)
        //    {
        //        interpretProgram();
        //        showStatus();
        //    }
        //}
    }
}

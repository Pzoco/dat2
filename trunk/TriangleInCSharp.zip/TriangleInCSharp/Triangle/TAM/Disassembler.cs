﻿using System;
using System.IO;

namespace Tools.TAM
{
    public class Disassembler
    {
        static String objectName;

        static int CT;

        /**
         * Writes the r-field of an instruction in the form "l<I>reg</I>r", where
         * l and r are the bracket characters to use.
         * @param leftbracket		the character to print before the register.
         * @param r			the number of the register.
         * @param rightbracket 	the character to print after the register.
         */
        //private static void writeR(char leftbracket, int r, char rightbracket)
        private static void WriteR(char leftbracket, Machine.RegisterNumber r, char rightbracket)
        {

            Console.Write(leftbracket);
            switch (r)
            {
                case Machine.RegisterNumber.CBr:
                    Console.Write("CB");
                    break;
                case Machine.RegisterNumber.CTr:
                    Console.Write("CT");
                    break;
                case Machine.RegisterNumber.PBr:
                    Console.Write("PB");
                    break;
                case Machine.RegisterNumber.PTr:
                    Console.Write("PT");
                    break;
                case Machine.RegisterNumber.SBr:
                    Console.Write("SB");
                    break;
                case Machine.RegisterNumber.STr:
                    Console.Write("ST");
                    break;
                case Machine.RegisterNumber.HBr:
                    Console.Write("HB");
                    break;
                case Machine.RegisterNumber.HTr:
                    Console.Write("HT");
                    break;
                case Machine.RegisterNumber.LBr:
                    Console.Write("LB");
                    break;
                case Machine.RegisterNumber.L1r:
                    Console.Write("L1");
                    break;
                case Machine.RegisterNumber.L2r:
                    Console.Write("L2");
                    break;
                case Machine.RegisterNumber.L3r:
                    Console.Write("L3");
                    break;
                case Machine.RegisterNumber.L4r:
                    Console.Write("L4");
                    break;
                case Machine.RegisterNumber.L5r:
                    Console.Write("L5");
                    break;
                case Machine.RegisterNumber.L6r:
                    Console.Write("L6");
                    break;
                case Machine.RegisterNumber.CPr:
                    Console.Write("CP");
                    break;
            }
            Console.Write(rightbracket);
        }

        /**
         * Writes a void n-field of an instruction.
         */
        private static void BlankN()
        {
            Console.Write("      ");
        }

        // Writes the n-field of an instruction.
        /**
         * Writes the n-field of an instruction in the form "(n)".
         * @param n	the integer to write.
         */
        private static void WriteN(int n)
        {
            Console.Write("(" + n + ") ");
            if (n < 10)
                Console.Write("  ");
            else if (n < 100)
                Console.Write(" ");
        }

        /**
         * Writes the d-field of an instruction.
         * @param d	the integer to write.
         */
        private static void WriteD(int d)
        {
            Console.Write(d);
        }

        /**
         * Writes the name of primitive routine with relative address d.
         * @param d	the displacment of the primitive routine.
         */
        private static void WritePrimitive(Machine.PrimitiveRoutine d)
        {
            switch (d)
            {
                case Machine.PrimitiveRoutine.idDisplacement:
                    Console.Write("id      ");
                    break;
                case Machine.PrimitiveRoutine.notDisplacement:
                    Console.Write("not     ");
                    break;
                case Machine.PrimitiveRoutine.andDisplacement:
                    Console.Write("and     ");
                    break;
                case Machine.PrimitiveRoutine.orDisplacement:
                    Console.Write("or      ");
                    break;
                case Machine.PrimitiveRoutine.succDisplacement:
                    Console.Write("succ    ");
                    break;
                case Machine.PrimitiveRoutine.predDisplacement:
                    Console.Write("pred    ");
                    break;
                case Machine.PrimitiveRoutine.negDisplacement:
                    Console.Write("neg     ");
                    break;
                case Machine.PrimitiveRoutine.addDisplacement:
                    Console.Write("add     ");
                    break;
                case Machine.PrimitiveRoutine.subDisplacement:
                    Console.Write("sub     ");
                    break;
                case Machine.PrimitiveRoutine.multDisplacement:
                    Console.Write("mult    ");
                    break;
                case Machine.PrimitiveRoutine.divDisplacement:
                    Console.Write("div     ");
                    break;
                case Machine.PrimitiveRoutine.modDisplacement:
                    Console.Write("mod     ");
                    break;
                case Machine.PrimitiveRoutine.ltDisplacement:
                    Console.Write("lt      ");
                    break;
                case Machine.PrimitiveRoutine.leDisplacement:
                    Console.Write("le      ");
                    break;
                case Machine.PrimitiveRoutine.geDisplacement:
                    Console.Write("ge      ");
                    break;
                case Machine.PrimitiveRoutine.gtDisplacement:
                    Console.Write("gt      ");
                    break;
                case Machine.PrimitiveRoutine.eqDisplacement:
                    Console.Write("eq      ");
                    break;
                case Machine.PrimitiveRoutine.neDisplacement:
                    Console.Write("ne      ");
                    break;
                case Machine.PrimitiveRoutine.eolDisplacement:
                    Console.Write("eol     ");
                    break;
                case Machine.PrimitiveRoutine.eofDisplacement:
                    Console.Write("eof     ");
                    break;
                case Machine.PrimitiveRoutine.getDisplacement:
                    Console.Write("get     ");
                    break;
                case Machine.PrimitiveRoutine.putDisplacement:
                    Console.Write("put     ");
                    break;
                case Machine.PrimitiveRoutine.geteolDisplacement:
                    Console.Write("geteol  ");
                    break;
                case Machine.PrimitiveRoutine.puteolDisplacement:
                    Console.Write("puteol  ");
                    break;
                case Machine.PrimitiveRoutine.getintDisplacement:
                    Console.Write("getint  ");
                    break;
                case Machine.PrimitiveRoutine.putintDisplacement:
                    Console.Write("putint  ");
                    break;
                case Machine.PrimitiveRoutine.newDisplacement:
                    Console.Write("new     ");
                    break;
                case Machine.PrimitiveRoutine.disposeDisplacement:
                    Console.Write("dispose ");
                    break;
            }
        }

        /**
         * Writes the given instruction in assembly-code format.
         * @param instr	the instruction to display.
         */
        private static void WriteInstruction(Instruction instr)
        {

            switch ((Machine.Opcode)instr.op)
            {
                case (int)Machine.Opcode.LOADop:
                    Console.Write("LOAD  ");
                    WriteN(instr.n);
                    WriteD((int)instr.d);
                    WriteR('[', (Machine.RegisterNumber)instr.r, ']');
                    break;

                case Machine.Opcode.LOADAop:
                    Console.Write("LOADA ");
                    BlankN();
                    WriteD((int)instr.d);
                    WriteR('[', (Machine.RegisterNumber)instr.r, ']');
                    break;

                case Machine.Opcode.LOADIop:
                    Console.Write("LOADI ");
                    WriteN(instr.n);
                    break;

                case Machine.Opcode.LOADLop:
                    Console.Write("LOADL ");
                    BlankN();
                    WriteD((int)instr.d);
                    break;

                case Machine.Opcode.STOREop:
                    Console.Write("STORE ");
                    WriteN(instr.n);
                    WriteD((int)instr.d);
                    WriteR('[', (Machine.RegisterNumber)instr.r, ']');
                    break;

                case Machine.Opcode.STOREIop:
                    Console.Write("STOREI");
                    WriteN(instr.n);
                    break;

                case Machine.Opcode.CALLop:
                    Console.Write("CALL  ");
                    if (instr.r == (int)Machine.RegisterNumber.PBr)
                    {
                        BlankN();
                        WritePrimitive((Machine.PrimitiveRoutine)instr.d);
                    }
                    else
                    {
                        WriteR('(', (Machine.RegisterNumber)instr.n, ')');
                        Console.Write("  ");
                        WriteD((int)instr.d);
                        WriteR('[', (Machine.RegisterNumber)instr.r, ']');
                    }
                    break;

                case Machine.Opcode.CALLIop:
                    Console.Write("CALLI ");
                    break;

                case Machine.Opcode.RETURNop:
                    Console.Write("RETURN");
                    WriteN(instr.n);
                    WriteD((int)instr.d);
                    break;

                case Machine.Opcode.PUSHop:
                    Console.Write("PUSH  ");
                    BlankN();
                    WriteD((int)instr.d);
                    break;

                case Machine.Opcode.POPop:
                    Console.Write("POP   ");
                    WriteN(instr.n);
                    WriteD((int)instr.d);
                    break;

                case Machine.Opcode.JUMPop:
                    Console.Write("JUMP  ");
                    BlankN();
                    WriteD((int)instr.d);
                    WriteR('[', (Machine.RegisterNumber)instr.r, ']');
                    break;

                case Machine.Opcode.JUMPIop:
                    Console.Write("JUMPI ");
                    break;

                case Machine.Opcode.JUMPIFop:
                    Console.Write("JUMPIF");
                    WriteN(instr.n);
                    WriteD((int)instr.d);
                    WriteR('[', (Machine.RegisterNumber)instr.r, ']');
                    break;

                case Machine.Opcode.HALTop:
                    Console.Write("HALT  ");
                    break;
            }
        }

        /**
         * Writes all instructions of the program in code store.
         */
        private static void DisassembleProgram()
        {
            for (int addr = (int)Machine.CodeStoreRegister.CB; addr < CT; addr++)
            {
                Console.Write(addr + ":  ");
                WriteInstruction(Machine.code[addr]);
                Console.WriteLine();
            }
        }


        // LOADING

        /**
         * Loads the TAM object program into code store from the named file.
         * @param objectName	the name of the file containing the program.
         */
        static void LoadObjectProgram(String objectName)
        {

            FileStream objectFile = null;
            BinaryReader objectStream = null;

            int addr;
            bool finished = false;

            try
            {
                objectFile = new FileStream(objectName, FileMode.Open);
                objectStream = new BinaryReader(objectFile);

                addr = (int)Machine.CodeStoreRegister.CB;
                while (!finished)
                {
                    Machine.code[addr] = Instruction.Read(objectStream);
                    if (Machine.code[addr] == null)
                        finished = true;
                    else
                        addr = addr + 1;
                }
                CT = addr;
                objectFile.Close();
            }
            catch (FileNotFoundException s)
            {
                CT = (int)Machine.CodeStoreRegister.CB;
                Console.Error.WriteLine("Error opening object file: " + s);
            }
            catch (IOException s)
            {
                CT = (int)Machine.CodeStoreRegister.CB;
                Console.Error.WriteLine("Error reading object file: " + s);
            }
        }
    }
}
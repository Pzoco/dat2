﻿using System;
using Tools.Triangle.AbstractSyntaxTrees;
using Tools.Triangle.CodeGenerator;
using Tools.Triangle.ContextualAnalyzer;
using Tools.Triangle.SyntacticAnalyzer;
using Tools.Triangle.TreeDrawer;

namespace Tools.Triangle
{
    public class Compiler
    {

        /** The filename for the object program, normally obj.tam. */
        static String objectName = "obj.tam";

        private static Scanner scanner;
        private static Parser parser;
        private static Checker checker;
        private static Encoder encoder;
        private static ErrorReporter reporter;
        private static Drawer drawer;

        /** The AST representing the source program. */
        private static Program theAST;

        /**
         * Compile the source program to TAM machine code.
         *
         * @param	sourceName	the name of the file containing the
         *				source program.
         * @param	objectName	the name of the file containing the
         *				object program.
         * @param	showingAST	true iff the AST is to be displayed after
         *				contextual analysis (not currently implemented).
         * @param	showingTable	true iff the object description details are to
         *				be displayed during code generation (not
         *				currently implemented).
         * @return	true iff the source program is free of compile-time errors,
         *          otherwise false.
         */
        static bool CompileProgram(String sourceName, String objectName, bool showingAST, bool showingTable)
        {
            Console.WriteLine("********** " +
                               "Triangle Compiler (Java Version 2.1)" + //TODO
                               " **********");

            Console.WriteLine("Syntactic Analysis ...");
            SourceFile source = new SourceFile(sourceName);

            if (source == null)
            {
                Console.WriteLine("Can't access source file " + sourceName);
                Environment.Exit(1); 
            }

            scanner = new Scanner(source);
            reporter = new ErrorReporter();
            parser = new Parser(scanner, reporter);
            checker = new Checker(reporter);
            encoder = new Encoder(reporter);
            drawer = new Drawer();

            // scanner.enableDebugging();
            theAST = parser.ParseProgram();				// 1st pass
            if (reporter.numErrors == 0)
            {
                //if (showingAST) {
                //    drawer.draw(theAST);
                //}
                Console.WriteLine("Contextual Analysis ...");
                checker.Check(theAST);				// 2nd pass
                if (showingAST)
                {
                    drawer.Draw(theAST);
                }
                if (reporter.numErrors == 0)
                {
                    Console.WriteLine("Code Generation ...");
                    encoder.EncodeRun(theAST, showingTable);	// 3rd pass
                }
            }

            bool successful = (reporter.numErrors == 0);
            if (successful)
            {
                encoder.SaveObjectProgram(objectName);
                Console.WriteLine("Compilation was successful.");
            }
            else
            {
                Console.WriteLine("Compilation was unsuccessful.");
            }
            return successful;
        }

        /**
         * Triangle compiler main program.
         *
         * @param	args	the only command-line argument to the program specifies
         *                  the source filename.
         */
        public static void Main(String[] args)
        {
            bool compiledOK;

            if (args.Length != 1)
            {
                Console.WriteLine("Usage: tc filename");
                Environment.Exit(1);
            }

            String sourceName = args[0];
            compiledOK = CompileProgram(sourceName, objectName, false, false);
        }
    }
}

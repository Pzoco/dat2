﻿using System;
using Tools.TAM;
using Tools.Triangle.TreeDrawer;
using Tools.Triangle.AbstractSyntaxTrees;
using System.IO;

namespace Tools.Triangle.CodeGenerator
{
    public sealed class Encoder : Visitor
    {
        // Commands
        public Object VisitAssignCommand(AssignCommand ast, Object o)
        {
            Frame frame = (Frame)o;
            int valSize = (int)ast.E.Visit(this, frame);
            EncodeStore(ast.V, new Frame(frame, valSize), valSize);
            return null;
        }

        public Object VisitCallCommand(CallCommand ast, Object o)
        {
            Frame frame = (Frame)o;
            int argsSize = (int)ast.APS.Visit(this, frame);
            ast.I.Visit(this, new Frame(frame.level, argsSize));
            return null;
        }

        public Object VisitEmptyCommand(EmptyCommand ast, Object o)
        {
            return null;
        }

        public Object VisitIfCommand(IfCommand ast, Object o)
        {
            Frame frame = (Frame)o;
            int jumpifAddr, jumpAddr;
            int valSize = (int)ast.E.Visit(this, frame);
            jumpifAddr = nextInstrAddr;
            Emit((int)Machine.Opcode.JUMPIFop, (int)Machine.DataRepresentation.falseRep, (int)Machine.RegisterNumber.CBr, (int)Machine.PrimitiveRoutine.NoValue);
            ast.C1.Visit(this, frame);
            jumpAddr = nextInstrAddr;
            Emit((int)Machine.Opcode.JUMPop, 0, (int)Machine.RegisterNumber.CBr, (int)Machine.PrimitiveRoutine.NoValue);
            Patch(jumpifAddr, nextInstrAddr);
            ast.C2.Visit(this, frame);
            Patch(jumpAddr, nextInstrAddr);
            return null;
        }

        public Object VisitLetCommand(LetCommand ast, Object o)
        {
            Frame frame = (Frame)o;
            int extraSize = ((int)ast.D.Visit(this, frame));
            ast.C.Visit(this, new Frame(frame, extraSize));
            if (extraSize > 0)
                Emit((int)Machine.Opcode.POPop, 0, (int)Machine.RegisterNumber.NoValue, extraSize);
            return null;
        }

        public Object VisitSequentialCommand(SequentialCommand ast, Object o)
        {
            ast.C1.Visit(this, o);
            ast.C2.Visit(this, o);
            return null;
        }

        public Object VisitWhileCommand(WhileCommand ast, Object o)
        {
            Frame frame = (Frame)o;
            int jumpAddr, loopAddr;

            jumpAddr = nextInstrAddr;
            Emit((int)Machine.Opcode.JUMPop, 0, (int)Machine.RegisterNumber.CBr, 0);
            loopAddr = nextInstrAddr;
            ast.C.Visit(this, frame);
            Patch(jumpAddr, nextInstrAddr);
            ast.E.Visit(this, frame);
            Emit((int)Machine.Opcode.JUMPIFop, (int)Machine.DataRepresentation.trueRep, (int)Machine.RegisterNumber.CBr, loopAddr);
            return null;
        }


        // Expressions
        public Object VisitArrayExpression(ArrayExpression ast, Object o)
        {
            ast.type.Visit(this, null);
            return ast.AA.Visit(this, o);
        }

        public Object VisitBinaryExpression(BinaryExpression ast, Object o)
        {
            Frame frame = (Frame)o;
            int valSize = (int)ast.type.Visit(this, null);
            int valSize1 = ((int)ast.E1.Visit(this, frame));
            Frame frame1 = new Frame(frame, valSize1);
            int valSize2 = ((int)ast.E2.Visit(this, frame1));
            Frame frame2 = new Frame(frame.level, valSize1 + valSize2);
            ast.O.Visit(this, frame2);
            return valSize;
        }

        public Object VisitCallExpression(CallExpression ast, Object o)
        {
            Frame frame = (Frame)o;
            int valSize = (int)ast.type.Visit(this, null);
            int argsSize = (int)ast.APS.Visit(this, frame);
            ast.I.Visit(this, new Frame(frame.level, argsSize));
            return valSize;
        }

        public Object VisitCharacterExpression(CharacterExpression ast, Object o)
        {
            Frame frame = (Frame)o;
            int valSize = (int)ast.type.Visit(this, null);
            Emit((int)Machine.Opcode.LOADLop, 0, 0, ast.CL.spelling[1]);
            return valSize;
        }

        public Object VisitEmptyExpression(EmptyExpression ast, Object o)
        {
            return 0;
        }

        public Object VisitIfExpression(IfExpression ast, Object o)
        {
            Frame frame = (Frame)o;
            int valSize;
            int jumpifAddr, jumpAddr;

            ast.type.Visit(this, null);
            ast.E1.Visit(this, frame);
            jumpifAddr = nextInstrAddr;
            Emit((int)Machine.Opcode.JUMPIFop, (int)Machine.DataRepresentation.falseRep, (int)Machine.RegisterNumber.CBr, 0);
            valSize = (int)ast.E2.Visit(this, frame);
            jumpAddr = nextInstrAddr;
            Emit((int)Machine.Opcode.JUMPop, 0, (int)Machine.RegisterNumber.CBr, 0);
            Patch(jumpifAddr, nextInstrAddr);
            valSize = (int)ast.E3.Visit(this, frame);
            Patch(jumpAddr, nextInstrAddr);
            return valSize;
        }

        public Object VisitIntegerExpression(IntegerExpression ast, Object o)
        {
            Frame frame = (Frame)o;
            int valSize = (int)ast.type.Visit(this, null);
            Emit((int)Machine.Opcode.LOADLop, 0, 0, int.Parse(ast.IL.spelling));
            return valSize;
        }

        public Object VisitLetExpression(LetExpression ast, Object o)
        {
            Frame frame = (Frame)o;
            ast.type.Visit(this, null);
            int extraSize = ((int)ast.D.Visit(this, frame));
            Frame frame1 = new Frame(frame, extraSize);
            int valSize = (int)ast.E.Visit(this, frame1);
            if (extraSize > 0)
                Emit((int)Machine.Opcode.POPop, valSize, 0, extraSize);
            return valSize;
        }

        public Object VisitRecordExpression(RecordExpression ast, Object o)
        {
            ast.type.Visit(this, null);
            return ast.RA.Visit(this, o);
        }

        public Object VisitUnaryExpression(UnaryExpression ast, Object o)
        {
            Frame frame = (Frame)o;
            int valSize = (int)ast.type.Visit(this, null);
            ast.E.Visit(this, frame);
            ast.O.Visit(this, new Frame(frame.level, valSize));
            return valSize;
        }

        public Object VisitVnameExpression(VnameExpression ast, Object o)
        {
            Frame frame = (Frame)o;
            int valSize = (int)ast.type.Visit(this, null);
            EncodeFetch(ast.V, frame, valSize);
            return valSize;
        }


        // Declarations
        public Object VisitBinaryOperatorDeclaration(BinaryOperatorDeclaration ast, Object o)
        {
            return 0;
        }

        public Object VisitConstDeclaration(ConstDeclaration ast, Object o)
        {
            Frame frame = (Frame)o;
            int extraSize = 0;

            if (ast.E is CharacterExpression)
            {
                CharacterLiteral CL = ((CharacterExpression)ast.E).CL;
                ast.entity = new KnownValue((int)Machine.DataRepresentation.characterSize, CharacterValuation(CL.spelling));
            }
            else if (ast.E is IntegerExpression)
            {
                IntegerLiteral IL = ((IntegerExpression)ast.E).IL;
                ast.entity = new KnownValue((int)Machine.DataRepresentation.integerSize, int.Parse(IL.spelling));
            }
            else
            {
                int valSize = ((int)ast.E.Visit(this, frame));
                ast.entity = new UnknownValue(valSize, frame.level, frame.size);
                extraSize = valSize;
            }
            WriteTableDetails(ast);
            return extraSize;
        }

        public Object VisitFuncDeclaration(FuncDeclaration ast, Object o)
        {
            Frame frame = (Frame)o;
            int jumpAddr = nextInstrAddr;
            int argsSize = 0, valSize = 0;

            Emit((int)Machine.Opcode.JUMPop, 0, (int)Machine.RegisterNumber.CBr, 0);
            ast.entity = new KnownRoutine((int)Machine.DataRepresentation.closureSize, frame.level, nextInstrAddr);
            WriteTableDetails(ast);
            if (frame.level == Machine.maxRoutineLevel)
                reporter.ReportRestriction("can't nest routines more than 7 deep");
            else
            {
                Frame frame1 = new Frame(frame.level + 1, 0);
                argsSize = ((int)ast.FPS.Visit(this, frame1));
                Frame frame2 = new Frame(frame.level + 1, (int)Machine.DataRepresentation.linkDataSize);
                valSize = ((int)ast.E.Visit(this, frame2));
            }
            Emit((int)Machine.Opcode.RETURNop, valSize, 0, argsSize);
            Patch(jumpAddr, nextInstrAddr);
            return 0;
        }

        public Object VisitProcDeclaration(ProcDeclaration ast, Object o)
        {
            Frame frame = (Frame)o;
            int jumpAddr = nextInstrAddr;
            int argsSize = 0;

            Emit((int)Machine.Opcode.JUMPop, 0, (int)Machine.RegisterNumber.CBr, 0);
            ast.entity = new KnownRoutine((int)Machine.DataRepresentation.closureSize, frame.level, nextInstrAddr);
            WriteTableDetails(ast);
            if (frame.level == Machine.maxRoutineLevel)
                reporter.ReportRestriction("can't nest routines so deeply");
            else
            {
                Frame frame1 = new Frame(frame.level + 1, 0);
                argsSize = ((int)ast.FPS.Visit(this, frame1));
                Frame frame2 = new Frame(frame.level + 1, (int)Machine.DataRepresentation.linkDataSize);
                ast.C.Visit(this, frame2);
            }
            Emit((int)Machine.Opcode.RETURNop, 0, 0, argsSize);
            Patch(jumpAddr, nextInstrAddr);
            return 0;
        }

        public Object VisitSequentialDeclaration(SequentialDeclaration ast, Object o)
        {
            Frame frame = (Frame)o;
            int extraSize1, extraSize2;
            extraSize1 = ((int)ast.D1.Visit(this, frame));
            Frame frame1 = new Frame(frame, extraSize1);
            extraSize2 = ((int)ast.D2.Visit(this, frame1));
            return extraSize1 + extraSize2;
        }

        public Object VisitTypeDeclaration(TypeDeclaration ast, Object o)
        {
            // just to ensure the type's representation is decided
            ast.T.Visit(this, null);
            return 0;
        }

        public Object VisitUnaryOperatorDeclaration(UnaryOperatorDeclaration ast, Object o)
        {
            return 0;
        }

        public Object VisitVarDeclaration(VarDeclaration ast, Object o)
        {
            Frame frame = (Frame)o;
            int extraSize;
            extraSize = ((int)ast.T.Visit(this, null));
            Emit((int)Machine.Opcode.PUSHop, 0, 0, extraSize);
            ast.entity = new KnownAddress((int)Machine.DataRepresentation.addressSize, frame.level, frame.size);
            WriteTableDetails(ast);
            return extraSize;
        }


        // Array Aggregates
        public Object VisitMultipleArrayAggregate(MultipleArrayAggregate ast, Object o)
        {
            Frame frame = (Frame)o;
            int elemSize = ((int)ast.E.Visit(this, frame));
            Frame frame1 = new Frame(frame, elemSize);
            int arraySize = ((int)ast.AA.Visit(this, frame1));
            return elemSize + arraySize;
        }

        public Object VisitSingleArrayAggregate(SingleArrayAggregate ast, Object o)
        {
            return ast.E.Visit(this, o);
        }


        // Record Aggregates
        public Object VisitMultipleRecordAggregate(MultipleRecordAggregate ast,
                               Object o)
        {
            Frame frame = (Frame)o;
            int fieldSize = ((int)ast.E.Visit(this, frame));
            Frame frame1 = new Frame(frame, fieldSize);
            int recordSize = ((int)ast.RA.Visit(this, frame1));
            return fieldSize + recordSize;
        }

        public Object VisitSingleRecordAggregate(SingleRecordAggregate ast,
                             Object o)
        {
            return ast.E.Visit(this, o);
        }


        // Formal Parameters
        public Object VisitConstFormalParameter(ConstFormalParameter ast, Object o)
        {
            Frame frame = (Frame)o;
            int valSize = ((int)ast.T.Visit(this, null));
            ast.entity = new UnknownValue(valSize, frame.level, -frame.size - valSize);
            WriteTableDetails(ast);
            return valSize;
        }

        public Object VisitFuncFormalParameter(FuncFormalParameter ast, Object o)
        {
            Frame frame = (Frame)o;
            int argsSize = (int)Machine.DataRepresentation.closureSize;
            ast.entity = new UnknownRoutine((int)Machine.DataRepresentation.closureSize, frame.level,
                          -frame.size - argsSize);
            WriteTableDetails(ast);
            return argsSize;
        }

        public Object VisitProcFormalParameter(ProcFormalParameter ast, Object o)
        {
            Frame frame = (Frame)o;
            int argsSize = (int)Machine.DataRepresentation.closureSize;
            ast.entity = new UnknownRoutine((int)Machine.DataRepresentation.closureSize, frame.level,
                          -frame.size - argsSize);
            WriteTableDetails(ast);
            return argsSize;
        }

        public Object VisitVarFormalParameter(VarFormalParameter ast, Object o)
        {
            Frame frame = (Frame)o;
            ast.T.Visit(this, null);
            ast.entity = new UnknownAddress((int)Machine.DataRepresentation.addressSize, frame.level,
                          -frame.size - (int)Machine.DataRepresentation.addressSize);
            WriteTableDetails(ast);
            return Machine.DataRepresentation.addressSize;
        }


        public Object VisitEmptyFormalParameterSequence(
           EmptyFormalParameterSequence ast, Object o)
        {
            return 0;
        }

        public Object VisitMultipleFormalParameterSequence(MultipleFormalParameterSequence ast, Object o)
        {
            Frame frame = (Frame)o;
            int argsSize1 = ((int)ast.FPS.Visit(this, frame));
            Frame frame1 = new Frame(frame, argsSize1);
            int argsSize2 = ((int)ast.FP.Visit(this, frame1));
            return argsSize1 + argsSize2;
        }

        public Object VisitSingleFormalParameterSequence(SingleFormalParameterSequence ast, Object o)
        {
            return ast.FP.Visit(this, o);
        }


        // Actual Parameters
        public Object VisitConstActualParameter(ConstActualParameter ast, Object o)
        {
            return ast.E.Visit(this, o);
        }

        public Object VisitFuncActualParameter(FuncActualParameter ast, Object o)
        {
            Frame frame = (Frame)o;
            if (ast.I.decl.entity is KnownRoutine)
            {
                ObjectAddress address = ((KnownRoutine)ast.I.decl.entity).address;
                // static link, code address
                Emit((int)Machine.Opcode.LOADAop, 0, DisplayRegister(frame.level, address.level), 0);
                Emit((int)Machine.Opcode.LOADAop, 0, (int)Machine.RegisterNumber.CBr, address.displacement);
            }
            else if (ast.I.decl.entity is UnknownRoutine)
            {
                ObjectAddress address = ((UnknownRoutine)ast.I.decl.entity).address;
                Emit((int)Machine.Opcode.LOADop, (int)Machine.DataRepresentation.closureSize, DisplayRegister(frame.level,
                     address.level), address.displacement);
            }
            else if (ast.I.decl.entity is PrimitiveRoutine)
            {
                int displacement = ((PrimitiveRoutine)ast.I.decl.entity).displacement;
                // static link, code address
                Emit((int)Machine.Opcode.LOADAop, 0, (int)Machine.RegisterNumber.SBr, 0);
                Emit((int)Machine.Opcode.LOADAop, 0, (int)Machine.RegisterNumber.PBr, displacement);
            }
            return Machine.DataRepresentation.closureSize;
        }

        public Object VisitProcActualParameter(ProcActualParameter ast, Object o)
        {
            Frame frame = (Frame)o;
            if (ast.I.decl.entity is KnownRoutine)
            {
                ObjectAddress address = ((KnownRoutine)ast.I.decl.entity).address;
                // static link, code address
                Emit((int)Machine.Opcode.LOADAop, 0, DisplayRegister(frame.level, address.level), 0);
                Emit((int)Machine.Opcode.LOADAop, 0, (int)Machine.RegisterNumber.CBr, address.displacement);
            }
            else if (ast.I.decl.entity is UnknownRoutine)
            {
                ObjectAddress address = ((UnknownRoutine)ast.I.decl.entity).address;
                Emit((int)Machine.Opcode.LOADop, (int)Machine.DataRepresentation.closureSize, DisplayRegister(frame.level,
                     address.level), address.displacement);
            }
            else if (ast.I.decl.entity is PrimitiveRoutine)
            {
                int displacement = ((PrimitiveRoutine)ast.I.decl.entity).displacement;
                // static link, code address
                Emit((int)Machine.Opcode.LOADAop, 0, (int)Machine.RegisterNumber.SBr, 0);
                Emit((int)Machine.Opcode.LOADAop, 0, (int)Machine.RegisterNumber.PBr, displacement);
            }
            return Machine.DataRepresentation.closureSize;
        }

        public Object VisitVarActualParameter(VarActualParameter ast, Object o)
        {
            EncodeFetchAddress(ast.V, (Frame)o);
            return Machine.DataRepresentation.addressSize;
        }


        public Object VisitEmptyActualParameterSequence(EmptyActualParameterSequence ast, Object o)
        {
            return 0;
        }

        public Object VisitMultipleActualParameterSequence(MultipleActualParameterSequence ast, Object o)
        {
            Frame frame = (Frame)o;
            int argsSize1 = ((int)ast.AP.Visit(this, frame));
            Frame frame1 = new Frame(frame, argsSize1);
            int argsSize2 = ((int)ast.APS.Visit(this, frame1));
            return argsSize1 + argsSize2;
        }

        public Object VisitSingleActualParameterSequence(SingleActualParameterSequence ast, Object o)
        {
            return ast.AP.Visit(this, o);
        }


        // Type Denoters
        public Object VisitAnyTypeDenoter(AnyTypeDenoter ast, Object o)
        {
            return 0;
        }

        public Object VisitArrayTypeDenoter(ArrayTypeDenoter ast, Object o)
        {
            int typeSize;
            if (ast.entity == null)
            {
                int elemSize = ((int)ast.T.Visit(this, null));
                typeSize = int.Parse(ast.IL.spelling) * elemSize;
                ast.entity = new TypeRepresentation(typeSize);
                WriteTableDetails(ast);
            }
            else
                typeSize = ast.entity.size;
            return typeSize;
        }

        public Object VisitBoolTypeDenoter(BoolTypeDenoter ast, Object o)
        {
            if (ast.entity == null)
            {
                ast.entity = new TypeRepresentation((int)Machine.DataRepresentation.booleanSize);
                WriteTableDetails(ast);
            }
            return Machine.DataRepresentation.booleanSize;
        }

        public Object VisitCharTypeDenoter(CharTypeDenoter ast, Object o)
        {
            if (ast.entity == null)
            {
                ast.entity = new TypeRepresentation((int)Machine.DataRepresentation.characterSize);
                WriteTableDetails(ast);
            }
            return Machine.DataRepresentation.characterSize;
        }

        public Object VisitErrorTypeDenoter(ErrorTypeDenoter ast, Object o)
        {
            return 0;
        }

        public Object VisitSimpleTypeDenoter(SimpleTypeDenoter ast, Object o)
        {
            return 0;
        }

        public Object VisitIntTypeDenoter(IntTypeDenoter ast, Object o)
        {
            if (ast.entity == null)
            {
                ast.entity = new TypeRepresentation((int)Machine.DataRepresentation.integerSize);
                WriteTableDetails(ast);
            }
            return Machine.DataRepresentation.integerSize;
        }

        public Object VisitRecordTypeDenoter(RecordTypeDenoter ast, Object o)
        {
            int typeSize;
            if (ast.entity == null)
            {
                typeSize = ((int)ast.FT.Visit(this, 0));
                ast.entity = new TypeRepresentation(typeSize);
                WriteTableDetails(ast);
            }
            else
                typeSize = ast.entity.size;
            return typeSize;
        }


        public Object VisitMultipleFieldTypeDenoter(MultipleFieldTypeDenoter ast, Object o)
        {
            int offset = (int)o;
            int fieldSize;

            if (ast.entity == null)
            {
                fieldSize = ((int)ast.T.Visit(this, null));
                ast.entity = new Field(fieldSize, offset);
                WriteTableDetails(ast);
            }
            else
                fieldSize = ast.entity.size;

            int offset1 = offset + fieldSize;
            int recSize = ((int)ast.FT.Visit(this, offset1));
            return fieldSize + recSize;
        }

        public Object VisitSingleFieldTypeDenoter(SingleFieldTypeDenoter ast, Object o)
        {
            int offset = (int)o;
            int fieldSize;

            if (ast.entity == null)
            {
                fieldSize = ((int)ast.T.Visit(this, null));
                ast.entity = new Field(fieldSize, offset);
                WriteTableDetails(ast);
            }
            else
                fieldSize = ast.entity.size;

            return fieldSize;
        }


        // Literals, Identifiers and Operators
        public Object VisitCharacterLiteral(CharacterLiteral ast, Object o)
        {
            return null;
        }

        public Object VisitIdentifier(Identifier ast, Object o)
        {
            Frame frame = (Frame)o;
            if (ast.decl.entity is KnownRoutine)
            {
                ObjectAddress address = ((KnownRoutine)ast.decl.entity).address;
                Emit((int)Machine.Opcode.CALLop, DisplayRegister(frame.level, address.level),
                 (int)Machine.RegisterNumber.CBr, address.displacement);
            }
            else if (ast.decl.entity is UnknownRoutine)
            {
                ObjectAddress address = ((UnknownRoutine)ast.decl.entity).address;
                Emit((int)Machine.Opcode.LOADop, (int)Machine.DataRepresentation.closureSize, DisplayRegister(frame.level,
                     address.level), address.displacement);
                Emit((int)Machine.Opcode.CALLIop, 0, 0, 0);
            }
            else if (ast.decl.entity is PrimitiveRoutine)
            {
                int displacement = ((PrimitiveRoutine)ast.decl.entity).displacement;
                if (displacement != (int)Machine.PrimitiveRoutine.idDisplacement)
                    Emit((int)Machine.Opcode.CALLop, (int)Machine.RegisterNumber.SBr, (int)Machine.RegisterNumber.PBr, displacement);
            }
            else if (ast.decl.entity is EqualityRoutine)
            { // "=" or "\="
                int displacement = ((EqualityRoutine)ast.decl.entity).displacement;
                Emit((int)Machine.Opcode.LOADLop, 0, 0, frame.size / 2);
                Emit((int)Machine.Opcode.CALLop, (int)Machine.RegisterNumber.SBr, (int)Machine.RegisterNumber.PBr, displacement);
            }
            return null;
        }

        public Object VisitIntegerLiteral(IntegerLiteral ast, Object o)
        {
            return null;
        }

        public Object VisitOperator(Operator ast, Object o)
        {
            Frame frame = (Frame)o;
            if (ast.decl.entity is KnownRoutine)
            {
                ObjectAddress address = ((KnownRoutine)ast.decl.entity).address;
                Emit((int)Machine.Opcode.CALLop, DisplayRegister(frame.level, address.level),
                 (int)Machine.RegisterNumber.CBr, address.displacement);
            }
            else if (ast.decl.entity is UnknownRoutine)
            {
                ObjectAddress address = ((UnknownRoutine)ast.decl.entity).address;
                Emit((int)Machine.Opcode.LOADop, (int)Machine.DataRepresentation.closureSize, DisplayRegister(frame.level,
                     address.level), address.displacement);
                Emit((int)Machine.Opcode.CALLIop, 0, 0, 0);
            }
            else if (ast.decl.entity is PrimitiveRoutine)
            {
                int displacement = ((PrimitiveRoutine)ast.decl.entity).displacement;
                if (displacement != (int)Machine.PrimitiveRoutine.idDisplacement)
                    Emit((int)Machine.Opcode.CALLop, (int)Machine.RegisterNumber.SBr, (int)Machine.RegisterNumber.PBr, displacement);
            }
            else if (ast.decl.entity is EqualityRoutine)
            { // "=" or "\="
                int displacement = ((EqualityRoutine)ast.decl.entity).displacement;
                Emit((int)Machine.Opcode.LOADLop, 0, 0, frame.size / 2);
                Emit((int)Machine.Opcode.CALLop, (int)Machine.RegisterNumber.SBr, (int)Machine.RegisterNumber.PBr, displacement);
            }
            return null;
        }


        // Value-or-variable names
        public Object VisitDotVname(DotVname ast, Object o)
        {
            Frame frame = (Frame)o;
            RuntimeEntity baseObject = (RuntimeEntity)ast.V.Visit(this, frame);
            ast.offset = ast.V.offset + ((Field)ast.I.decl.entity).fieldOffset;
            // I.decl points to the appropriate record field
            ast.indexed = ast.V.indexed;
            return baseObject;
        }

        public Object VisitSimpleVname(SimpleVname ast, Object o)
        {
            ast.offset = 0;
            ast.indexed = false;
            return ast.I.decl.entity;
        }

        public Object VisitSubscriptVname(SubscriptVname ast, Object o)
        {
            Frame frame = (Frame)o;
            RuntimeEntity baseObject;
            int elemSize, indexSize;

            baseObject = (RuntimeEntity)ast.V.Visit(this, frame);
            ast.offset = ast.V.offset;
            ast.indexed = ast.V.indexed;
            elemSize = ((int)ast.type.Visit(this, null));
            if (ast.E is IntegerExpression)
            {
                IntegerLiteral IL = ((IntegerExpression)ast.E).IL;
                ast.offset = ast.offset + int.Parse(IL.spelling) * elemSize;
            }
            else
            {
                // v-name is indexed by a proper expression, not a literal
                if (ast.indexed)
                    frame.size = frame.size + (int)Machine.DataRepresentation.integerSize;
                //indexSize = ((Integer)ast.E.visit(this, frame)).intValue();//TODO
                indexSize = ((int)ast.E.Visit(this, frame));
                if (elemSize != 1)
                {
                    Emit((int)Machine.Opcode.LOADLop, 0, 0, elemSize);
                    Emit((int)Machine.Opcode.CALLop, (int)Machine.RegisterNumber.SBr, (int)Machine.RegisterNumber.PBr,
                         (int)Machine.PrimitiveRoutine.multDisplacement);
                }
                if (ast.indexed)
                    Emit((int)Machine.Opcode.CALLop, (int)Machine.RegisterNumber.SBr, (int)Machine.RegisterNumber.PBr, (int)Machine.PrimitiveRoutine.addDisplacement);
                else
                    ast.indexed = true;
            }
            return baseObject;
        }


        // Programs
        public Object VisitProgram(Program ast, Object o)
        {
            return ast.C.Visit(this, o);
        }

        public Encoder(ErrorReporter reporter)
        {
            this.reporter = reporter;
            nextInstrAddr = (int)Machine.CodeStoreRegister.CB;
            ElaborateStdEnvironment();
        }

        private ErrorReporter reporter;

        // Generates code to run a program.
        // showingTable is true iff entity description details
        // are to be displayed.
        public void EncodeRun(Program theAST, bool showingTable) //TODO was Final
        {
            tableDetailsReqd = showingTable;
            //startCodeGeneration();
            theAST.Visit(this, new Frame(0, 0));
            Emit((int)Machine.Opcode.HALTop, 0, 0, 0);
        }

        // Decides run-time representation of a standard constant.
        private void ElaborateStdConst(Declaration constDeclaration, int value)
        {

            if (constDeclaration is ConstDeclaration)
            {
                ConstDeclaration decl = (ConstDeclaration)constDeclaration;
                int typeSize = ((int)decl.E.type.Visit(this, null));
                decl.entity = new KnownValue(typeSize, value);
                WriteTableDetails(constDeclaration);
            }
        }

        // Decides run-time representation of a standard routine.
        private void ElaborateStdPrimRoutine(Declaration routineDeclaration,int routineOffset)
        {
            routineDeclaration.entity = new PrimitiveRoutine((int)Machine.DataRepresentation.closureSize, routineOffset);
            WriteTableDetails(routineDeclaration);
        }

        private void ElaborateStdEqRoutine(Declaration routineDeclaration,int routineOffset)
        {
            routineDeclaration.entity = new EqualityRoutine((int)Machine.DataRepresentation.closureSize, routineOffset);
            WriteTableDetails(routineDeclaration);
        }

        private void ElaborateStdRoutine(Declaration routineDeclaration,int routineOffset)
        {
            routineDeclaration.entity = new KnownRoutine((int)Machine.DataRepresentation.closureSize, 0, routineOffset);
            WriteTableDetails(routineDeclaration);
        }

        private void ElaborateStdEnvironment()
        {
            tableDetailsReqd = false;
            ElaborateStdConst(StdEnvironment.falseDecl, (int)Machine.DataRepresentation.falseRep);
            ElaborateStdConst(StdEnvironment.trueDecl, (int)Machine.DataRepresentation.trueRep);
            ElaborateStdPrimRoutine(StdEnvironment.notDecl, (int)Machine.PrimitiveRoutine.notDisplacement);
            ElaborateStdPrimRoutine(StdEnvironment.andDecl, (int)Machine.PrimitiveRoutine.andDisplacement);
            ElaborateStdPrimRoutine(StdEnvironment.orDecl, (int)Machine.PrimitiveRoutine.orDisplacement);
            ElaborateStdConst(StdEnvironment.maxintDecl, (int)Machine.DataRepresentation.maxintRep);
            ElaborateStdPrimRoutine(StdEnvironment.addDecl, (int)Machine.PrimitiveRoutine.addDisplacement);
            ElaborateStdPrimRoutine(StdEnvironment.subtractDecl, (int)Machine.PrimitiveRoutine.subDisplacement);
            ElaborateStdPrimRoutine(StdEnvironment.multiplyDecl, (int)Machine.PrimitiveRoutine.multDisplacement);
            ElaborateStdPrimRoutine(StdEnvironment.divideDecl, (int)Machine.PrimitiveRoutine.divDisplacement);
            ElaborateStdPrimRoutine(StdEnvironment.moduloDecl, (int)Machine.PrimitiveRoutine.modDisplacement);
            ElaborateStdPrimRoutine(StdEnvironment.lessDecl, (int)Machine.PrimitiveRoutine.ltDisplacement);
            ElaborateStdPrimRoutine(StdEnvironment.notgreaterDecl, (int)Machine.PrimitiveRoutine.leDisplacement);
            ElaborateStdPrimRoutine(StdEnvironment.greaterDecl, (int)Machine.PrimitiveRoutine.gtDisplacement);
            ElaborateStdPrimRoutine(StdEnvironment.notlessDecl, (int)Machine.PrimitiveRoutine.geDisplacement);
            ElaborateStdPrimRoutine(StdEnvironment.chrDecl, (int)Machine.PrimitiveRoutine.idDisplacement);
            ElaborateStdPrimRoutine(StdEnvironment.ordDecl, (int)Machine.PrimitiveRoutine.idDisplacement);
            ElaborateStdPrimRoutine(StdEnvironment.eolDecl, (int)Machine.PrimitiveRoutine.eolDisplacement);
            ElaborateStdPrimRoutine(StdEnvironment.eofDecl, (int)Machine.PrimitiveRoutine.eofDisplacement);
            ElaborateStdPrimRoutine(StdEnvironment.getDecl, (int)Machine.PrimitiveRoutine.getDisplacement);
            ElaborateStdPrimRoutine(StdEnvironment.putDecl, (int)Machine.PrimitiveRoutine.putDisplacement);
            ElaborateStdPrimRoutine(StdEnvironment.getintDecl, (int)Machine.PrimitiveRoutine.getintDisplacement);
            ElaborateStdPrimRoutine(StdEnvironment.putintDecl, (int)Machine.PrimitiveRoutine.putintDisplacement);
            ElaborateStdPrimRoutine(StdEnvironment.geteolDecl, (int)Machine.PrimitiveRoutine.geteolDisplacement);
            ElaborateStdPrimRoutine(StdEnvironment.puteolDecl, (int)Machine.PrimitiveRoutine.puteolDisplacement);
            ElaborateStdEqRoutine(StdEnvironment.equalDecl, (int)Machine.PrimitiveRoutine.eqDisplacement);
            ElaborateStdEqRoutine(StdEnvironment.unequalDecl, (int)Machine.PrimitiveRoutine.neDisplacement);
        }

        // Saves the object program in the named file.

        public void SaveObjectProgram(String objectName)
        {
            FileStream objectFile = null;
            BinaryWriter objectStream = null;

            int addr;

            try
            {
                objectFile = new FileStream(objectName, FileMode.OpenOrCreate);
                objectStream = new BinaryWriter(objectFile);

                addr = (int)Machine.CodeStoreRegister.CB;
                for (addr = (int)Machine.CodeStoreRegister.CB; addr < nextInstrAddr; addr++)
                    Machine.code[addr].Write(objectStream);
                objectFile.Close();
            }
            catch (FileNotFoundException s)
            {
                Console.Error.WriteLine("Error opening object file: " + s);
            }
            catch (IOException s)
            {
                Console.Error.WriteLine("Error writing object file: " + s);
            }
        }

        bool tableDetailsReqd;

        public static void WriteTableDetails(AST ast)
        {
        }

        // OBJECT CODE

        // Implementation notes:
        // Object code is generated directly into the TAM Code Store, starting at CB.
        // The address of the next instruction is held in nextInstrAddr.

        private int nextInstrAddr;

        // Appends an instruction, with the given fields, to the object code.
        //emit((int)Machine.Opcode.CALLop, (int)Machine.RegisterNumber.SBr, (int)Machine.RegisterNumber.PBr, (int)Machine.PrimitiveRoutine.addDisplacement); TODO REMOVE
        private void Emit(int op, int n, int r, int d)
        {
            Instruction nextInstr = new Instruction();
            if (n > 255)
            {
                reporter.ReportRestriction("length of operand can't exceed 255 words");
                n = 255; // to allow code generation to continue
            }
            nextInstr.op = op;
            nextInstr.n = n;
            nextInstr.r = r;
            nextInstr.d = d;
            if (nextInstrAddr == (int)Machine.CodeStoreRegister.PB)
                reporter.ReportRestriction("too many instructions for code segment");
            else
            {
                Machine.code[nextInstrAddr] = nextInstr;
                nextInstrAddr = nextInstrAddr + 1;
            }
        }

        // Patches the d-field of the instruction at address addr.
        private void Patch(int addr, int d)
        {
            Machine.code[addr].d = d;
        }

        // DATA REPRESENTATION

        public int CharacterValuation(String spelling)
        {
            // Returns the machine representation of the given character literal.
            return spelling[1];
            // since the character literal is of the form 'x'}
        }

        // REGISTERS

        // Returns the register number appropriate for object code at currentLevel
        // to address a data object at objectLevel.
        private int DisplayRegister(int currentLevel, int objectLevel)
        {
            if (objectLevel == 0)
                return (int)Machine.RegisterNumber.SBr;
            else if (currentLevel - objectLevel <= 6)
                return (int)Machine.RegisterNumber.LBr + currentLevel - objectLevel; // LBr|L1r|...|L6r
            else
            {
                reporter.ReportRestriction("can't access data more than 6 levels out");
                return (int)Machine.RegisterNumber.L6r;  // to allow code generation to continue
            }
        }

        // Generates code to fetch the value of a named constant or variable
        // and push it on to the stack.
        // currentLevel is the routine level where the vname occurs.
        // frameSize is the anticipated size of the local stack frame when
        // the constant or variable is fetched at run-time.
        // valSize is the size of the constant or variable's value.

        private void EncodeStore(Vname V, Frame frame, int valSize)
        {

            RuntimeEntity baseObject = (RuntimeEntity)V.Visit(this, frame);
            // If indexed = true, code will have been generated to load an index value.
            if (valSize > 255)
            {
                reporter.ReportRestriction("can't store values larger than 255 words");
                valSize = 255; // to allow code generation to continue
            }
            if (baseObject is KnownAddress)
            {
                ObjectAddress address = ((KnownAddress)baseObject).address;
                if (V.indexed)
                {
                    Emit((int)Machine.Opcode.LOADAop, 0, DisplayRegister(frame.level, address.level),
                         address.displacement + V.offset);
                    Emit((int)Machine.Opcode.CALLop, (int)Machine.RegisterNumber.SBr, (int)Machine.RegisterNumber.PBr, (int)Machine.PrimitiveRoutine.addDisplacement);
                    Emit((int)Machine.Opcode.STOREIop, valSize, 0, 0);
                }
                else
                {
                    Emit((int)Machine.Opcode.STOREop, valSize, DisplayRegister(frame.level,
                     address.level), address.displacement + V.offset);
                }
            }
            else if (baseObject is UnknownAddress)
            {
                ObjectAddress address = ((UnknownAddress)baseObject).address;
                Emit((int)Machine.Opcode.LOADop, (int)Machine.DataRepresentation.addressSize, DisplayRegister(frame.level,
                     address.level), address.displacement);
                if (V.indexed)
                    Emit((int)Machine.Opcode.CALLop, (int)Machine.RegisterNumber.SBr, (int)Machine.RegisterNumber.PBr, (int)Machine.PrimitiveRoutine.addDisplacement);
                if (V.offset != 0)
                {
                    Emit((int)Machine.Opcode.LOADLop, 0, 0, V.offset);
                    Emit((int)Machine.Opcode.CALLop, (int)Machine.RegisterNumber.SBr, (int)Machine.RegisterNumber.PBr, (int)Machine.PrimitiveRoutine.addDisplacement);
                }
                Emit((int)Machine.Opcode.STOREIop, valSize, 0, 0);
            }
        }

        // Generates code to fetch the value of a named constant or variable
        // and push it on to the stack.
        // currentLevel is the routine level where the vname occurs.
        // frameSize is the anticipated size of the local stack frame when
        // the constant or variable is fetched at run-time.
        // valSize is the size of the constant or variable's value.

        private void EncodeFetch(Vname V, Frame frame, int valSize)
        {

            RuntimeEntity baseObject = (RuntimeEntity)V.Visit(this, frame);
            // If indexed = true, code will have been generated to load an index value.
            if (valSize > 255)
            {
                reporter.ReportRestriction("can't load values larger than 255 words");
                valSize = 255; // to allow code generation to continue
            }
            if (baseObject is KnownValue)
            {
                // presumably offset = 0 and indexed = false
                int value = ((KnownValue)baseObject).value;
                Emit((int)Machine.Opcode.LOADLop, 0, 0, value);
            }
            else if ((baseObject is UnknownValue) ||
                       (baseObject is KnownAddress))
            {
                ObjectAddress address = (baseObject is UnknownValue) ?
                                        ((UnknownValue)baseObject).address :
                                        ((KnownAddress)baseObject).address;
                if (V.indexed)
                {
                    Emit((int)Machine.Opcode.LOADAop, 0, DisplayRegister(frame.level, address.level),
                         address.displacement + V.offset);
                    Emit((int)Machine.Opcode.CALLop, (int)Machine.RegisterNumber.SBr, (int)Machine.RegisterNumber.PBr, (int)Machine.PrimitiveRoutine.addDisplacement);
                    Emit((int)Machine.Opcode.LOADIop, valSize, 0, 0);
                }
                else
                    Emit((int)Machine.Opcode.LOADop, valSize, DisplayRegister(frame.level,
                     address.level), address.displacement + V.offset);
            }
            else if (baseObject is UnknownAddress)
            {
                ObjectAddress address = ((UnknownAddress)baseObject).address;
                Emit((int)Machine.Opcode.LOADop, (int)Machine.DataRepresentation.addressSize, DisplayRegister(frame.level,
                     address.level), address.displacement);
                if (V.indexed)
                    Emit((int)Machine.Opcode.CALLop, (int)Machine.RegisterNumber.SBr, (int)Machine.RegisterNumber.PBr, (int)Machine.PrimitiveRoutine.addDisplacement);
                if (V.offset != 0)
                {
                    Emit((int)Machine.Opcode.LOADLop, 0, 0, V.offset);
                    Emit((int)Machine.Opcode.CALLop, (int)Machine.RegisterNumber.SBr, (int)Machine.RegisterNumber.PBr, (int)Machine.PrimitiveRoutine.addDisplacement);
                }
                Emit((int)Machine.Opcode.LOADIop, valSize, 0, 0);
            }
        }

        // Generates code to compute and push the address of a named variable.
        // vname is the program phrase that names this variable.
        // currentLevel is the routine level where the vname occurs.
        // frameSize is the anticipated size of the local stack frame when
        // the variable is addressed at run-time.

        private void EncodeFetchAddress(Vname V, Frame frame)
        {

            RuntimeEntity baseObject = (RuntimeEntity)V.Visit(this, frame);
            // If indexed = true, code will have been generated to load an index value.
            if (baseObject is KnownAddress)
            {
                ObjectAddress address = ((KnownAddress)baseObject).address;
                Emit((int)Machine.Opcode.LOADAop, 0, DisplayRegister(frame.level, address.level),
                     address.displacement + V.offset);
                if (V.indexed)
                    Emit((int)Machine.Opcode.CALLop, (int)Machine.RegisterNumber.SBr, (int)Machine.RegisterNumber.PBr, (int)Machine.PrimitiveRoutine.addDisplacement);
            }
            else if (baseObject is UnknownAddress)
            {
                ObjectAddress address = ((UnknownAddress)baseObject).address;
                Emit((int)Machine.Opcode.LOADop, (int)Machine.DataRepresentation.addressSize, DisplayRegister(frame.level,
                     address.level), address.displacement);
                if (V.indexed)
                    Emit((int)Machine.Opcode.CALLop, (int)Machine.RegisterNumber.SBr, (int)Machine.RegisterNumber.PBr, (int)Machine.PrimitiveRoutine.addDisplacement);
                if (V.offset != 0)
                {
                    Emit((int)Machine.Opcode.LOADLop, 0, 0, V.offset);
                    Emit((int)Machine.Opcode.CALLop, (int)Machine.RegisterNumber.SBr, (int)Machine.RegisterNumber.PBr, (int)Machine.PrimitiveRoutine.addDisplacement);
                }
            }
        }
    }
}

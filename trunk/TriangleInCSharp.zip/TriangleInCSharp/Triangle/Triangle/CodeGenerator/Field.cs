﻿using System;

namespace Tools.Triangle.CodeGenerator
{
    public class Field : RuntimeEntity
    {
        public Field()
            : base()
        {
            fieldOffset = 0;
        }

        public Field(int size, int fieldOffset)
            : base(size)
        {
            this.fieldOffset = fieldOffset;
        }

        public int fieldOffset;
    }
}

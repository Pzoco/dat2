﻿using System;

namespace Tools.Triangle.CodeGenerator
{
    public class UnknownAddress : RuntimeEntity
    {
        public UnknownAddress()
            : base()
        {
            address = null;
        }

        public UnknownAddress(int size, int level, int displacement)
            : base(size)
        {
            address = new ObjectAddress(level, displacement);
        }

        public ObjectAddress address;
    }
}

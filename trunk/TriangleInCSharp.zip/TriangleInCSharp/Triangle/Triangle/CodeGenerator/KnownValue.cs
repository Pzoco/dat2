﻿using System;

namespace Tools.Triangle.CodeGenerator
{
    public class KnownValue : RuntimeEntity
    {
        public KnownValue()
            : base()
        {
            value = 0;
        }

        public KnownValue(int size, int value)
            : base(size)
        {
            this.value = value;
        }

        public int value;
    }
}

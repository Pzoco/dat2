﻿using System;

namespace Tools.Triangle.CodeGenerator
{
    public class EqualityRoutine : RuntimeEntity
    {
        public EqualityRoutine()
            : base()
        {
        }

        public EqualityRoutine(int size, int displacement)
            : base(size)
        {
            this.displacement = displacement;
        }

        public int displacement;
    }
}

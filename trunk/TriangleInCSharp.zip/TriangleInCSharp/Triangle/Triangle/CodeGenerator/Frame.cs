﻿using System;

namespace Tools.Triangle.CodeGenerator
{
    public class Frame
    {
        public Frame()
        {
            this.level = 0;
            this.size = 0;
        }

        public Frame(int level, int size)
        {
            this.level = level;
            this.size = size;
        }

        public Frame(Frame frame, int sizeIncrement)
        {
            this.level = frame.level;
            this.size = frame.size + sizeIncrement;
        }
        
        public int level;
        public int size;
    }
}
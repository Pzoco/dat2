﻿using System;

namespace Tools.Triangle.CodeGenerator
{
    public class TypeRepresentation : RuntimeEntity
    {
        public TypeRepresentation(int size)
            : base(size)
        {
        }
    }
}

﻿using System;

namespace Tools.Triangle.CodeGenerator
{
    public class KnownAddress : RuntimeEntity
    {
        public KnownAddress()
            : base()
        {
            address = null;
        }

        public KnownAddress(int size, int level, int displacement)
            : base(size)
        {
            address = new ObjectAddress(level, displacement);
        }

        public ObjectAddress address;
    }
}

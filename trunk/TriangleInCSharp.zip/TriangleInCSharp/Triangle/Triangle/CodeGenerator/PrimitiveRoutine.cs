﻿using System;

namespace Tools.Triangle.CodeGenerator
{
    public class PrimitiveRoutine : RuntimeEntity
    {
        public PrimitiveRoutine()
            : base()
        {
            displacement = 0;
        }

        public PrimitiveRoutine(int size, int displacement)
            : base(size)
        {
            this.displacement = displacement;
        }

        public int displacement;
    }
}

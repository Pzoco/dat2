﻿using System;

namespace Tools.Triangle.CodeGenerator
{
    public abstract class RuntimeEntity
    {
        public static int maxRoutineLevel = 7;


        public RuntimeEntity()
        {
            size = 0;
        }

        public RuntimeEntity(int size)
        {
            this.size = size;
        }

        public int size;

    }
}

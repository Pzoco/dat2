﻿using System;

namespace Tools.Triangle.CodeGenerator
{
    public class KnownRoutine : RuntimeEntity
    {
        public KnownRoutine()
            : base()
        {
            address = null;
        }

        public KnownRoutine(int size, int level, int displacement)
            : base(size)
        {
            address = new ObjectAddress(level, displacement);
        }

        public ObjectAddress address;
    }
}

﻿using System;

namespace Tools.Triangle.CodeGenerator
{
    public sealed class ObjectAddress
    {
        public ObjectAddress(int level, int displacement)
        {
            this.level = level;
            this.displacement = displacement;
        }

        public int level, displacement;
    }
}

﻿using System;

namespace Tools.Triangle.CodeGenerator
{
    public class UnknownValue : RuntimeEntity
    {
        public UnknownValue()
            : base()
        {
            address = null;
        }

        public UnknownValue(int size, int level, int displacement)
            : base(size)
        {
            address = new ObjectAddress(level, displacement);
        }

        public ObjectAddress address;
    }
}

﻿using System;
using Tools.Triangle.AbstractSyntaxTrees;

namespace Tools.Triangle.TreeDrawer
{
    public class Drawer
    {

        //private DrawerFrame frame;
        //private DrawerPanel panel;

        //private Program theAST;
        //private DrawingTree theDrawing;

        // Draw the AST representing a complete program.

        public void Draw(Program ast)//TODO
        {
            //theAST = ast;
            //panel = new DrawerPanel(this);
            //frame = new DrawerFrame(panel);

            //Font font = new Font("SansSerif", Font.PLAIN, 12);
            //frame.setFont(font);

            //FontMetrics fontMetrics = frame.getFontMetrics(font);

            //LayoutVisitor layout = new LayoutVisitor(fontMetrics);
            //theDrawing = (DrawingTree)theAST.visit(layout, null);
            //theDrawing.position(new Point(2048, 10));

            //frame.show();
        }

        //public void paintAST(Graphics g)//TODO
        //{
            //g.setColor(panel.getBackground());
            //Dimension d = panel.getSize();
            //g.fillRect(0, 0, d.width, d.height);

            //if (theDrawing != null)
            //{
            //    theDrawing.paint(g);
            //}
        //}
    }

}

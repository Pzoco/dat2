﻿using System;
using Tools.Triangle.AbstractSyntaxTrees;

namespace Tools.Triangle
{
    public sealed class StdEnvironment
    {
        // These are small ASTs representing standard types.

        public static TypeDenoter
          booleanType, charType, integerType, anyType, errorType;

        public static TypeDeclaration
          booleanDecl, charDecl, integerDecl;

        // These are small ASTs representing "declarations" of standard entities.

        public static ConstDeclaration
          falseDecl, trueDecl, maxintDecl;

        public static UnaryOperatorDeclaration
          notDecl;

        public static BinaryOperatorDeclaration
          andDecl, orDecl,
          addDecl, subtractDecl, multiplyDecl, divideDecl, moduloDecl,
          equalDecl, unequalDecl, lessDecl, notlessDecl, greaterDecl, notgreaterDecl;

        public static ProcDeclaration
          getDecl, putDecl, getintDecl, putintDecl, geteolDecl, puteolDecl;

        public static FuncDeclaration
          chrDecl, ordDecl, eolDecl, eofDecl;
    }
}

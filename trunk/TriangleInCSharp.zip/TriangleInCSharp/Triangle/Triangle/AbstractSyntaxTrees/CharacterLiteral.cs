﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class CharacterLiteral : Terminal
    {
        public CharacterLiteral(String theSpelling, SourcePosition thePosition)
            : base(theSpelling, thePosition)
        {

        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitCharacterLiteral(this, o);
        }
    }
}

﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class IntegerLiteral : Terminal
    {
        public IntegerLiteral(String theSpelling, SourcePosition thePosition)
            : base(theSpelling, thePosition)
        {

        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitIntegerLiteral(this, o);
        }
    }
}

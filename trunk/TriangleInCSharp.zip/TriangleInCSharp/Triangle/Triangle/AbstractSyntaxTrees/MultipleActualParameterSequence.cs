﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class MultipleActualParameterSequence : ActualParameterSequence
    {
        public MultipleActualParameterSequence(ActualParameter apAST, ActualParameterSequence apsAST, SourcePosition thePosition)
            : base(thePosition)
        {
            AP = apAST;
            APS = apsAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitMultipleActualParameterSequence(this, o);
        }

        public ActualParameter AP;
        public ActualParameterSequence APS;
    }
}

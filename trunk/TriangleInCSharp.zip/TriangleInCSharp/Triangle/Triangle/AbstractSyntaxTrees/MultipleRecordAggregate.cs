﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class MultipleRecordAggregate : RecordAggregate
    {
        public MultipleRecordAggregate(Identifier iAST, Expression eAST, RecordAggregate raAST, SourcePosition thePosition)
            : base(thePosition)
        {
            I = iAST;
            E = eAST;
            RA = raAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitMultipleRecordAggregate(this, o);
        }

        public Identifier I;
        public Expression E;
        public RecordAggregate RA;
    }
}

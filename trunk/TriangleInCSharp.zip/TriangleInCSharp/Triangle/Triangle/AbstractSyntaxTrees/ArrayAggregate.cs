﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public abstract class ArrayAggregate : AST
    {
        public ArrayAggregate(SourcePosition thePosition)
            : base(thePosition)
        {
            elemCount = 0;
        }

        public int elemCount;
    }
}

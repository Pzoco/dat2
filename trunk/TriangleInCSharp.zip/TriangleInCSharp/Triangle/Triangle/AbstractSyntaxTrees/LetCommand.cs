﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class LetCommand : Command
    {
        public LetCommand(Declaration dAST, Command cAST, SourcePosition thePosition)
            : base(thePosition)
        {
            D = dAST;
            C = cAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitLetCommand(this, o);
        }

        public Declaration D;
        public Command C;
    }
}

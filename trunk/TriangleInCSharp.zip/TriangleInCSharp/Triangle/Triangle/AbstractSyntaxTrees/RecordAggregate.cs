﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public abstract class RecordAggregate : AST
    {
        public RecordAggregate(SourcePosition thePosition)
            : base(thePosition)
        {
            type = null;
        }

        public FieldTypeDenoter type;
    }
}

﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public abstract class FormalParameter : Declaration
    {
        public FormalParameter(SourcePosition thePosition)
            : base(thePosition)
        {

        }

        public abstract override bool Equals(Object fpAST);
    }
}

﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class UnaryOperatorDeclaration : Declaration
    {
        public UnaryOperatorDeclaration(Operator oAST, TypeDenoter argAST, TypeDenoter resultAST, SourcePosition thePosition)
            : base(thePosition)
        {
            O = oAST;
            ARG = argAST;
            RES = resultAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitUnaryOperatorDeclaration(this, o);
        }

        public Operator O;
        public TypeDenoter ARG, RES;
    }
}

﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class CharacterExpression : Expression
    {
        public CharacterExpression(CharacterLiteral clAST, SourcePosition thePosition)
            : base(thePosition)
        {
            CL = clAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitCharacterExpression(this, o);
        }

        public CharacterLiteral CL;
    }
}

﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class AnyTypeDenoter : TypeDenoter
    {
        public AnyTypeDenoter(SourcePosition thePosition)
            : base(thePosition)
        {

        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitAnyTypeDenoter(this, o);
        }

        public override bool Equals(Object obj)
        {
            return false;
        }
    }
}

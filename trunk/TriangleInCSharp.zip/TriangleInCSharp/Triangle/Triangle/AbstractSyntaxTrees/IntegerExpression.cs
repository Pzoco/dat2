﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class IntegerExpression : Expression
    {
        public IntegerExpression(IntegerLiteral ilAST, SourcePosition thePosition)
            : base(thePosition)
        {
            IL = ilAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitIntegerExpression(this, o);
        }

        public IntegerLiteral IL;
    }
}

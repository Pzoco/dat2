﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class FuncActualParameter : ActualParameter
    {
        public FuncActualParameter(Identifier iAST, SourcePosition thePosition)
            : base(thePosition)
        {
            I = iAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitFuncActualParameter(this, o);
        }

        public Identifier I;
    }
}

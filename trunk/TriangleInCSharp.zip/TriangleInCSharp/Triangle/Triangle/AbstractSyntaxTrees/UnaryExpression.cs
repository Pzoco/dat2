﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class UnaryExpression : Expression
    {
        public UnaryExpression(Operator oAST, Expression eAST, SourcePosition thePosition)
            : base(thePosition)
        {
            O = oAST;
            E = eAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitUnaryExpression(this, o);
        }

        public Expression E;
        public Operator O;
    }
}

﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class MultipleArrayAggregate : ArrayAggregate
    {
        public MultipleArrayAggregate(Expression eAST, ArrayAggregate aaAST, SourcePosition thePosition)
            : base(thePosition)
        {
            E = eAST;
            AA = aaAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitMultipleArrayAggregate(this, o);
        }

        public Expression E;
        public ArrayAggregate AA;
    }
}

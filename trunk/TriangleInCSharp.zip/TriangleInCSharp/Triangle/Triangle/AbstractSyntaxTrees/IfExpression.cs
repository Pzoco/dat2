﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class IfExpression : Expression
    {
        public IfExpression(Expression e1AST, Expression e2AST, Expression e3AST, SourcePosition thePosition)
            : base(thePosition)
        {
            E1 = e1AST;
            E2 = e2AST;
            E3 = e3AST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitIfExpression(this, o);
        }

        public Expression E1, E2, E3;
    }
}

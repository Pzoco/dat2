﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class SequentialCommand : Command
    {
        public SequentialCommand(Command c1AST, Command c2AST, SourcePosition thePosition)
            : base(thePosition)
        {
            C1 = c1AST;
            C2 = c2AST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitSequentialCommand(this, o);
        }

        public Command C1, C2;
    }
}

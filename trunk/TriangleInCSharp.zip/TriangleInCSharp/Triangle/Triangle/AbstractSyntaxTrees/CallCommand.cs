﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class CallCommand : Command
    {
        public CallCommand(Identifier iAST, ActualParameterSequence apsAST, SourcePosition thePosition)
            : base(thePosition)
        {
            I = iAST;
            APS = apsAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitCallCommand(this, o);
        }

        public Identifier I;
        public ActualParameterSequence APS;
    }
}

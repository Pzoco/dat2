﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class MultipleFormalParameterSequence : FormalParameterSequence
    {
        public MultipleFormalParameterSequence(FormalParameter fpAST, FormalParameterSequence fpsAST, SourcePosition thePosition)
            : base(thePosition)
        {
            FP = fpAST;
            FPS = fpsAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitMultipleFormalParameterSequence(this, o);
        }

        public override bool Equals(Object fpsAST)
        {
            if (fpsAST is MultipleFormalParameterSequence)
            {
                MultipleFormalParameterSequence mfpsAST =
                    (MultipleFormalParameterSequence)fpsAST;
                return FP.Equals(mfpsAST.FP) && FPS.Equals(mfpsAST.FPS);
            }
            else
                return false;
        }

        public FormalParameter FP;
        public FormalParameterSequence FPS;
    }
}

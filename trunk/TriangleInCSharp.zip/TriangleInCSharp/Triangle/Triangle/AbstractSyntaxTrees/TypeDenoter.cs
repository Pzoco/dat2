﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public abstract class TypeDenoter : AST, IEquatable<Object>
    {
        public TypeDenoter(SourcePosition thePosition)
            : base(thePosition)
        {

        }

        public abstract override bool Equals(Object obj);
    }
}

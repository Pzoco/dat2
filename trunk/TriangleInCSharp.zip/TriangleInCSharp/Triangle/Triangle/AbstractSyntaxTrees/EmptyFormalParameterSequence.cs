﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class EmptyFormalParameterSequence : FormalParameterSequence
    {
        public EmptyFormalParameterSequence(SourcePosition thePosition)
            : base(thePosition)
        {

        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitEmptyFormalParameterSequence(this, o);
        }

        public override bool Equals(Object fpsAST)
        {
            return (fpsAST is EmptyFormalParameterSequence);
        }
    }
}

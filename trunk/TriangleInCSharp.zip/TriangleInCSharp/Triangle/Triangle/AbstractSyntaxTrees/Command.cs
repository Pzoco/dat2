﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public abstract class Command : AST
    {
        public Command(SourcePosition thePosition)
            : base(thePosition)
        {

        }
    }
}

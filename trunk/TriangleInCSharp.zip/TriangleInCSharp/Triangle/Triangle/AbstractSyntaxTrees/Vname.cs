﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public abstract class Vname : AST
    {
        public Vname(SourcePosition thePosition)
            : base(thePosition)
        {
            variable = false;
            type = null;
        }

        public bool variable, indexed;
        public int offset;
        public TypeDenoter type;
    }
}

﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class ArrayTypeDenoter : TypeDenoter
    {
        public ArrayTypeDenoter(IntegerLiteral ilAST, TypeDenoter tAST, SourcePosition thePosition)
            : base(thePosition)
        {
            IL = ilAST;
            T = tAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitArrayTypeDenoter(this, o);
        }

        public override bool Equals(Object obj)
        {
            if (obj != null && obj is ErrorTypeDenoter)
                return true;
            else if (obj != null && obj is ArrayTypeDenoter)
                return this.IL.spelling.CompareTo(((ArrayTypeDenoter)obj).IL.spelling) == 0 && this.T.Equals(((ArrayTypeDenoter)obj).T);
            else
                return false;
        }

        public IntegerLiteral IL;
        public TypeDenoter T;
    }
}

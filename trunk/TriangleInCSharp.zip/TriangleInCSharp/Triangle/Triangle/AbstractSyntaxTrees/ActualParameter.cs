﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public abstract class ActualParameter : AST
    {
        public ActualParameter(SourcePosition thePosition)
            : base(thePosition)
        {

        }
    }
}

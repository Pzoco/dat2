﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class SingleRecordAggregate : RecordAggregate
    {
        public SingleRecordAggregate(Identifier iAST, Expression eAST, SourcePosition thePosition)
            : base(thePosition)
        {
            I = iAST;
            E = eAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitSingleRecordAggregate(this, o);
        }

        public Identifier I;
        public Expression E;
    }
}

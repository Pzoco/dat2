﻿using System;
using Tools.Triangle.CodeGenerator;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public abstract class AST 
    {
        public AST(SourcePosition thePosition)
        {
            position = thePosition;
            entity = null;
        }

        public SourcePosition GetPosition()
        {
            return position;
        }

        public abstract Object Visit(Visitor v, Object o);

        public SourcePosition position;
        public RuntimeEntity entity;
    }

}

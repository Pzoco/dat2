﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class FuncDeclaration : Declaration
    {
        public FuncDeclaration(Identifier iAST, FormalParameterSequence fpsAST, TypeDenoter tAST, Expression eAST, SourcePosition thePosition)
            : base(thePosition)
        {
            I = iAST;
            FPS = fpsAST;
            T = tAST;
            E = eAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitFuncDeclaration(this, o);
        }

        public Identifier I;
        public FormalParameterSequence FPS;
        public TypeDenoter T;
        public Expression E;
    }
}

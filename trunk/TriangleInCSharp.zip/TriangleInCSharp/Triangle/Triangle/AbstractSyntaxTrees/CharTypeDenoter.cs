﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class CharTypeDenoter : TypeDenoter
    {
        public CharTypeDenoter(SourcePosition thePosition)
            : base(thePosition)
        {

        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitCharTypeDenoter(this, o);
        }

        public override bool Equals(Object obj)
        {
            if (obj != null && obj is ErrorTypeDenoter)
                return true;
            else
                return (obj != null && obj is CharTypeDenoter);
        }
    }
}

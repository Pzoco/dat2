﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class ConstActualParameter : ActualParameter
    {
        public ConstActualParameter(Expression eAST, SourcePosition thePosition)
            : base(thePosition)
        {
            E = eAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitConstActualParameter(this, o);
        }

        public Expression E;
    }
}

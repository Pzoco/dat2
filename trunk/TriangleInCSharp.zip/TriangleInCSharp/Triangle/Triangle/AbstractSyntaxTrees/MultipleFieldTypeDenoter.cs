﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class MultipleFieldTypeDenoter : FieldTypeDenoter
    {
        public MultipleFieldTypeDenoter(Identifier iAST, TypeDenoter tAST, FieldTypeDenoter ftAST, SourcePosition thePosition)
            : base(thePosition)
        {
            I = iAST;
            T = tAST;
            FT = ftAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitMultipleFieldTypeDenoter(this, o);
        }

        public override bool Equals(Object obj)
        {
            if (obj != null && obj is MultipleFieldTypeDenoter)
            {
                MultipleFieldTypeDenoter ft = (MultipleFieldTypeDenoter)obj;
                return (this.I.spelling.CompareTo(ft.I.spelling) == 0) &&
                        this.T.Equals(ft.T) &&
                        this.FT.Equals(ft.FT);
            }
            else
                return false;
        }

        public Identifier I;
        public TypeDenoter T;
        public FieldTypeDenoter FT;
    }
}

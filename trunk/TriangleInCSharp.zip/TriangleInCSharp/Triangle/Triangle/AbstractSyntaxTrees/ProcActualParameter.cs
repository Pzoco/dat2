﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class ProcActualParameter : ActualParameter
    {
        public ProcActualParameter(Identifier iAST, SourcePosition thePosition)
            : base(thePosition)
        {
            I = iAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitProcActualParameter(this, o);
        }

        public Identifier I;
    }
}

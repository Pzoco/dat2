﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class ProcDeclaration : Declaration
    {
        public ProcDeclaration(Identifier iAST, FormalParameterSequence fpsAST, Command cAST, SourcePosition thePosition)
            : base(thePosition)
        {
            I = iAST;
            FPS = fpsAST;
            C = cAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitProcDeclaration(this, o);
        }

        public Identifier I;
        public FormalParameterSequence FPS;
        public Command C;
    }
}

﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public abstract class Expression : AST
    {
        public Expression(SourcePosition thePosition)
            : base(thePosition)
        {
            type = null;
        }

        public TypeDenoter type;
    }
}

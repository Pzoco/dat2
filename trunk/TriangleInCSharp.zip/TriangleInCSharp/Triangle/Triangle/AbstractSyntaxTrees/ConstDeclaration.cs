﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class ConstDeclaration : Declaration
    {
        public ConstDeclaration(Identifier iAST, Expression eAST, SourcePosition thePosition)
            : base(thePosition)
        {
            I = iAST;
            E = eAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitConstDeclaration(this, o);
        }

        public Identifier I;
        public Expression E;
    }
}

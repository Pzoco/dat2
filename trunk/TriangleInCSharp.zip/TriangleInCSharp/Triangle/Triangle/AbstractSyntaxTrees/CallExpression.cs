﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class CallExpression : Expression
    {
        public CallExpression(Identifier iAST, ActualParameterSequence apsAST, SourcePosition thePosition)
            : base(thePosition)
        {
            I = iAST;
            APS = apsAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitCallExpression(this, o);
        }

        public Identifier I;
        public ActualParameterSequence APS;
    }
}

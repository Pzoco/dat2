﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class DotVname : Vname
    {
        public DotVname(Vname vAST, Identifier iAST, SourcePosition thePosition)
            : base(thePosition)
        {
            V = vAST;
            I = iAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitDotVname(this, o);
        }

        public Identifier I;
        public Vname V;
    }
}

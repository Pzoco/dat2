﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class RecordExpression : Expression
    {
        public RecordExpression(RecordAggregate raAST, SourcePosition thePosition)
            : base(thePosition)
        {
            RA = raAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitRecordExpression(this, o);
        }

        public RecordAggregate RA;
    }
}

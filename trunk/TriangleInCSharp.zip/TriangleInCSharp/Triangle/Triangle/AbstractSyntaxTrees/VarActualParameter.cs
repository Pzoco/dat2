﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class VarActualParameter : ActualParameter
    {
        public VarActualParameter(Vname vAST, SourcePosition thePosition)
            : base(thePosition)
        {
            V = vAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitVarActualParameter(this, o);
        }

        public Vname V;
    }
}

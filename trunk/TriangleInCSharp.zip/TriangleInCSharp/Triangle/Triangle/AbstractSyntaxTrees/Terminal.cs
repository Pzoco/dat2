﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    abstract public class Terminal : AST
    {
        public Terminal(String theSpelling, SourcePosition thePosition)
            : base(thePosition)
        {
            spelling = theSpelling;
        }

        public String spelling;
    }
}

﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class WhileCommand : Command
    {
        public WhileCommand(Expression eAST, Command cAST, SourcePosition thePosition)
            : base(thePosition)
        {
            E = eAST;
            C = cAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitWhileCommand(this, o);
        }

        public Expression E;
        public Command C;
    }
}

﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class BinaryOperatorDeclaration : Declaration
    {
        public BinaryOperatorDeclaration(Operator oAST, TypeDenoter arg1AST, TypeDenoter arg2AST, TypeDenoter resultAST, SourcePosition thePosition)
            : base(thePosition)
        {
            O = oAST;
            ARG1 = arg1AST;
            ARG2 = arg2AST;
            RES = resultAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitBinaryOperatorDeclaration(this, o);
        }

        public Operator O;
        public TypeDenoter ARG1, ARG2, RES;
    }
}

﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class AssignCommand : Command
    {
        public AssignCommand(Vname vAST, Expression eAST, SourcePosition thePosition)
            : base(thePosition)
        {
            V = vAST;
            E = eAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitAssignCommand(this, o);
        }

        public Vname V;
        public Expression E;
    }
}

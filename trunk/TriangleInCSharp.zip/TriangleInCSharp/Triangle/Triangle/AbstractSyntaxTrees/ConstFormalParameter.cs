﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class ConstFormalParameter : FormalParameter
    {
        public ConstFormalParameter(Identifier iAST, TypeDenoter tAST, SourcePosition thePosition)
            : base(thePosition)
        {
            I = iAST;
            T = tAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitConstFormalParameter(this, o);
        }

        public Identifier I;
        public TypeDenoter T;

        public override bool Equals(Object fpAST)
        {
            if (fpAST is ConstFormalParameter)
            {
                ConstFormalParameter cfpAST = (ConstFormalParameter)fpAST;
                return T.Equals(cfpAST.T);
            }
            else
                return false;
        }
    }
}

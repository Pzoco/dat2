﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public abstract class FieldTypeDenoter : TypeDenoter
    {
        public FieldTypeDenoter(SourcePosition thePosition)
            : base(thePosition)
        {

        }

        public abstract override bool Equals(Object obj);
    }
}

﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class IfCommand : Command
    {
        public IfCommand(Expression eAST, Command c1AST, Command c2AST, SourcePosition thePosition)
            : base(thePosition)
        {
            E = eAST;
            C1 = c1AST;
            C2 = c2AST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitIfCommand(this, o);
        }

        public Expression E;
        public Command C1, C2;
    }
}

﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class SequentialDeclaration : Declaration
    {
        public SequentialDeclaration(Declaration d1AST, Declaration d2AST, SourcePosition thePosition)
            : base(thePosition)
        {
            D1 = d1AST;
            D2 = d2AST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitSequentialDeclaration(this, o);
        }

        public Declaration D1, D2;
    }
}

﻿using System;
using Tools.Triangle.SyntacticAnalyzer;
using Tools.Triangle.AbstractSyntaxTrees;

public class BinaryExpression : Expression
{
    public BinaryExpression(Expression e1AST, Operator oAST, Expression e2AST, SourcePosition thePosition)
        : base(thePosition)
    {
        O = oAST;
        E1 = e1AST;
        E2 = e2AST;
    }

    public override Object Visit(Visitor v, Object o)
    {
        return v.VisitBinaryExpression(this, o);
    }

    public Expression E1, E2;
    public Operator O;
}

﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class IntTypeDenoter : TypeDenoter
    {
        public IntTypeDenoter(SourcePosition thePosition)
            : base(thePosition)
        {

        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitIntTypeDenoter(this, o);
        }

        public override bool Equals(Object obj)
        {
            if (obj != null && obj is ErrorTypeDenoter)
                return true;
            else
                return (obj != null && obj is IntTypeDenoter);
        }
    }
}

﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class ArrayExpression : Expression
    {
        public ArrayExpression(ArrayAggregate aaAST, SourcePosition thePosition)
            : base(thePosition)
        {
            AA = aaAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitArrayExpression(this, o);
        }

        public ArrayAggregate AA;
    }
}

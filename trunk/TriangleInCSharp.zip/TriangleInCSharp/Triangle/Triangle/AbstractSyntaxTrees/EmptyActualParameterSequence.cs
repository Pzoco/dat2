﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class EmptyActualParameterSequence : ActualParameterSequence
    {
        public EmptyActualParameterSequence(SourcePosition thePosition)
            : base(thePosition)
        {

        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitEmptyActualParameterSequence(this, o);
        }
    }
}

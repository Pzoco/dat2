﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class RecordTypeDenoter : TypeDenoter
    {
        public RecordTypeDenoter(FieldTypeDenoter ftAST, SourcePosition thePosition)
            : base(thePosition)
        {
            FT = ftAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitRecordTypeDenoter(this, o);
        }

        public override bool Equals(Object obj)
        {
            if (obj != null && obj is ErrorTypeDenoter)
                return true;
            else if (obj != null && obj is RecordTypeDenoter)
                return this.FT.Equals(((RecordTypeDenoter)obj).FT);
            else
                return false;
        }

        public FieldTypeDenoter FT;
    }
}

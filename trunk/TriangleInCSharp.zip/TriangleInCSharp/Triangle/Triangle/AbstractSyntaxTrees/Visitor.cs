﻿using System;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public interface Visitor
    {
        // Commands
        Object VisitAssignCommand(AssignCommand ast, Object o);
        Object VisitCallCommand(CallCommand ast, Object o);
        Object VisitEmptyCommand(EmptyCommand ast, Object o);
        Object VisitIfCommand(IfCommand ast, Object o);
        Object VisitLetCommand(LetCommand ast, Object o);
        Object VisitSequentialCommand(SequentialCommand ast, Object o);
        Object VisitWhileCommand(WhileCommand ast, Object o);

        // Expressions
        Object VisitArrayExpression(ArrayExpression ast, Object o);
        Object VisitBinaryExpression(BinaryExpression ast, Object o);
        Object VisitCallExpression(CallExpression ast, Object o);
        Object VisitCharacterExpression(CharacterExpression ast, Object o);
        Object VisitEmptyExpression(EmptyExpression ast, Object o);
        Object VisitIfExpression(IfExpression ast, Object o);
        Object VisitIntegerExpression(IntegerExpression ast, Object o);
        Object VisitLetExpression(LetExpression ast, Object o);
        Object VisitRecordExpression(RecordExpression ast, Object o);
        Object VisitUnaryExpression(UnaryExpression ast, Object o);
        Object VisitVnameExpression(VnameExpression ast, Object o);

        // Declarations
        Object VisitBinaryOperatorDeclaration(BinaryOperatorDeclaration ast, Object o);
        Object VisitConstDeclaration(ConstDeclaration ast, Object o);
        Object VisitFuncDeclaration(FuncDeclaration ast, Object o);
        Object VisitProcDeclaration(ProcDeclaration ast, Object o);
        Object VisitSequentialDeclaration(SequentialDeclaration ast, Object o);
        Object VisitTypeDeclaration(TypeDeclaration ast, Object o);
        Object VisitUnaryOperatorDeclaration(UnaryOperatorDeclaration ast, Object o);
        Object VisitVarDeclaration(VarDeclaration ast, Object o);

        // Array Aggregates
        Object VisitMultipleArrayAggregate(MultipleArrayAggregate ast, Object o);
        Object VisitSingleArrayAggregate(SingleArrayAggregate ast, Object o);

        // Record Aggregates
        Object VisitMultipleRecordAggregate(MultipleRecordAggregate ast, Object o);
        Object VisitSingleRecordAggregate(SingleRecordAggregate ast, Object o);

        // Formal Parameters
        Object VisitConstFormalParameter(ConstFormalParameter ast, Object o);
        Object VisitFuncFormalParameter(FuncFormalParameter ast, Object o);
        Object VisitProcFormalParameter(ProcFormalParameter ast, Object o);
        Object VisitVarFormalParameter(VarFormalParameter ast, Object o);
        Object VisitEmptyFormalParameterSequence(EmptyFormalParameterSequence ast, Object o);
        Object VisitMultipleFormalParameterSequence(MultipleFormalParameterSequence ast, Object o);
        Object VisitSingleFormalParameterSequence(SingleFormalParameterSequence ast, Object o);

        // Actual Parameters
        Object VisitConstActualParameter(ConstActualParameter ast, Object o);
        Object VisitFuncActualParameter(FuncActualParameter ast, Object o);
        Object VisitProcActualParameter(ProcActualParameter ast, Object o);
        Object VisitVarActualParameter(VarActualParameter ast, Object o);
        Object VisitEmptyActualParameterSequence(EmptyActualParameterSequence ast, Object o);
        Object VisitMultipleActualParameterSequence(MultipleActualParameterSequence ast, Object o);
        Object VisitSingleActualParameterSequence(SingleActualParameterSequence ast, Object o);

        // Type Denoters
        Object VisitAnyTypeDenoter(AnyTypeDenoter ast, Object o);
        Object VisitArrayTypeDenoter(ArrayTypeDenoter ast, Object o);
        Object VisitBoolTypeDenoter(BoolTypeDenoter ast, Object o);
        Object VisitCharTypeDenoter(CharTypeDenoter ast, Object o);
        Object VisitErrorTypeDenoter(ErrorTypeDenoter ast, Object o);
        Object VisitSimpleTypeDenoter(SimpleTypeDenoter ast, Object o);
        Object VisitIntTypeDenoter(IntTypeDenoter ast, Object o);
        Object VisitRecordTypeDenoter(RecordTypeDenoter ast, Object o);
        Object VisitMultipleFieldTypeDenoter(MultipleFieldTypeDenoter ast, Object o);
        Object VisitSingleFieldTypeDenoter(SingleFieldTypeDenoter ast, Object o);

        // Literals, Identifiers and Operators
        Object VisitCharacterLiteral(CharacterLiteral ast, Object o);
        Object VisitIdentifier(Identifier ast, Object o);
        Object VisitIntegerLiteral(IntegerLiteral ast, Object o);
        Object VisitOperator(Operator ast, Object o);

        // Value-or-variable names
        Object VisitDotVname(DotVname ast, Object o);
        Object VisitSimpleVname(SimpleVname ast, Object o);
        Object VisitSubscriptVname(SubscriptVname ast, Object o);

        // Programs
        Object VisitProgram(Program ast, Object o);
    }
}

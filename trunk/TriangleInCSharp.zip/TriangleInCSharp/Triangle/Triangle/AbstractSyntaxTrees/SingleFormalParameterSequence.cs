﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class SingleFormalParameterSequence : FormalParameterSequence
    {
        public SingleFormalParameterSequence(FormalParameter fpAST, SourcePosition thePosition)
            : base(thePosition)
        {
            FP = fpAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitSingleFormalParameterSequence(this, o);
        }

        public override bool Equals(Object fpsAST)
        {
            if (fpsAST is SingleFormalParameterSequence)
            {
                SingleFormalParameterSequence sfpsAST = (SingleFormalParameterSequence)fpsAST;
                return FP.Equals(sfpsAST.FP);
            }
            else
                return false;
        }

        public FormalParameter FP;
    }
}

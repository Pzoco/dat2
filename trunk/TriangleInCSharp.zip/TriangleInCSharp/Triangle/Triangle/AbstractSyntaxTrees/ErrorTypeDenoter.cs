﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class ErrorTypeDenoter : TypeDenoter
    {
        public ErrorTypeDenoter(SourcePosition thePosition)
            : base(thePosition)
        {

        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitErrorTypeDenoter(this, o);
        }

        public override bool Equals(Object obj)
        {
            return true;
        }
    }
}

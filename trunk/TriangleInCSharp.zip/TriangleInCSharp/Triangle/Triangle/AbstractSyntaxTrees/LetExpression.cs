﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class LetExpression : Expression
    {
        public LetExpression(Declaration dAST, Expression eAST, SourcePosition thePosition)
            : base(thePosition)
        {
            D = dAST;
            E = eAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitLetExpression(this, o);
        }

        public Declaration D;
        public Expression E;
    }
}

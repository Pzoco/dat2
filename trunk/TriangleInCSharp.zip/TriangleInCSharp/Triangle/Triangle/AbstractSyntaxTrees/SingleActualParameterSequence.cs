﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class SingleActualParameterSequence : ActualParameterSequence
    {
        public SingleActualParameterSequence(ActualParameter apAST, SourcePosition thePosition)
            : base(thePosition)
        {
            AP = apAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitSingleActualParameterSequence(this, o);
        }

        public ActualParameter AP;
    }
}

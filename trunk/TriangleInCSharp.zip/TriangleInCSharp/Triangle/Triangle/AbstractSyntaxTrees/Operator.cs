﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class Operator : Terminal
    {
        public Operator(String theSpelling, SourcePosition thePosition)
            : base(theSpelling, thePosition)
        {
            decl = null;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitOperator(this, o);
        }

        public Declaration decl;
    }
}

﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class ProcFormalParameter : FormalParameter
    {
        public ProcFormalParameter(Identifier iAST, FormalParameterSequence fpsAST, SourcePosition thePosition)
            : base(thePosition)
        {
            I = iAST;
            FPS = fpsAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitProcFormalParameter(this, o);
        }

        public Identifier I;
        public FormalParameterSequence FPS;

        public override bool Equals(Object fpAST)
        {
            if (fpAST is ProcFormalParameter)
            {
                ProcFormalParameter pfpAST = (ProcFormalParameter)fpAST;
                return FPS.Equals(pfpAST.FPS);
            }
            else
                return false;
        }
    }
}

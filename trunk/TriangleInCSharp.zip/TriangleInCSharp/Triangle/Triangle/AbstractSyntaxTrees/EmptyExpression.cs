﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class EmptyExpression : Expression
    {
        public EmptyExpression(SourcePosition thePosition)
            : base(thePosition)
        {

        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitEmptyExpression(this, o);
        }
    }
}

﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class VarFormalParameter : FormalParameter
    {
        public VarFormalParameter(Identifier iAST, TypeDenoter tAST, SourcePosition thePosition)
            : base(thePosition)
        {
            I = iAST;
            T = tAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitVarFormalParameter(this, o);
        }

        public Identifier I;
        public TypeDenoter T;

        public override bool Equals(Object fpAST)
        {
            if (fpAST is VarFormalParameter)
            {
                VarFormalParameter vfpAST = (VarFormalParameter)fpAST;
                return T.Equals(vfpAST.T);
            }
            else
                return false;
        }
    }
}

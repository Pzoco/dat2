﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class VarDeclaration : Declaration
    {
        public VarDeclaration(Identifier iAST, TypeDenoter tAST, SourcePosition thePosition)
            : base(thePosition)
        {
            I = iAST;
            T = tAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitVarDeclaration(this, o);
        }

        public Identifier I;
        public TypeDenoter T;
    }
}

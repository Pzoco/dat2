﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class BoolTypeDenoter : TypeDenoter
    {
        public BoolTypeDenoter(SourcePosition thePosition)
            : base(thePosition)
        {

        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitBoolTypeDenoter(this, o);
        }

        public override bool Equals(Object obj)
        {
            if ((obj != null) && (obj is ErrorTypeDenoter))
                return true;
            else
                return ((obj != null) && (obj is BoolTypeDenoter));
        }
    }
}

﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class VnameExpression : Expression
    {
        public VnameExpression(Vname vAST, SourcePosition thePosition)
            : base(thePosition)
        {
            V = vAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitVnameExpression(this, o);
        }

        public Vname V;
    }
}

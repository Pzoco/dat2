﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class TypeDeclaration : Declaration
    {
        public TypeDeclaration(Identifier iAST, TypeDenoter tAST, SourcePosition thePosition)
            : base(thePosition)
        {
            I = iAST;
            T = tAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitTypeDeclaration(this, o);
        }

        public Identifier I;
        public TypeDenoter T;
    }
}

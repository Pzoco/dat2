﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class Identifier : Terminal
    {
        public Identifier(String theSpelling, SourcePosition thePosition)
            : base(theSpelling, thePosition)
        {
            type = null;
            decl = null;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitIdentifier(this, o);
        }

        public TypeDenoter type;
        public AST decl; // Either a Declaration or a FieldTypeDenoter
    }
}

﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public abstract class ActualParameterSequence : AST
    {
        public ActualParameterSequence(SourcePosition thePosition)
            : base(thePosition)
        {

        }
    }
}

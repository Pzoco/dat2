﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public abstract class Declaration : AST
    {
        public Declaration(SourcePosition thePosition)
            : base(thePosition)
        {
            duplicated = false;
        }

        public bool duplicated;
    }
}

﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class Program : AST
    {
        public Program(Command cAST, SourcePosition thePosition)
            : base(thePosition)
        {
            C = cAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitProgram(this, o);
        }

        public Command C;
    }
}

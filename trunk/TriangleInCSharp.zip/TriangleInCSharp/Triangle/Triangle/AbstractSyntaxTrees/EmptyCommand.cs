﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class EmptyCommand : Command
    {
        public EmptyCommand(SourcePosition thePosition)
            : base(thePosition)
        {

        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitEmptyCommand(this, o);
        }
    }
}

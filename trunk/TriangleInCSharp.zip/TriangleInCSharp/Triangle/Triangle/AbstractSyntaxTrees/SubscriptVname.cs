﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class SubscriptVname : Vname
    {
        public SubscriptVname(Vname vAST, Expression eAST, SourcePosition thePosition)
            : base(thePosition)
        {
            V = vAST;
            E = eAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitSubscriptVname(this, o);
        }

        public Expression E;
        public Vname V;
    }
}

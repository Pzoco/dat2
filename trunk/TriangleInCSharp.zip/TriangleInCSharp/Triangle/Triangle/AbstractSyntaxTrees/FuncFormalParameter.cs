﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class FuncFormalParameter : FormalParameter
    {
        public FuncFormalParameter(Identifier iAST, FormalParameterSequence fpsAST, TypeDenoter tAST, SourcePosition thePosition)
            : base(thePosition)
        {
            I = iAST;
            FPS = fpsAST;
            T = tAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitFuncFormalParameter(this, o);
        }

        public override bool Equals(Object fpAST)
        {
            if (fpAST is FuncFormalParameter)
            {
                FuncFormalParameter ffpAST = (FuncFormalParameter)fpAST;
                return FPS.Equals(ffpAST.FPS) && T.Equals(ffpAST.T);
            }
            else
                return false;
        }

        public Identifier I;
        public FormalParameterSequence FPS;
        public TypeDenoter T;
    }
}

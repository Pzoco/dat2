﻿using System;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.AbstractSyntaxTrees
{
    public class SingleArrayAggregate : ArrayAggregate
    {
        public SingleArrayAggregate(Expression eAST, SourcePosition thePosition)
            : base(thePosition)
        {
            E = eAST;
        }

        public override Object Visit(Visitor v, Object o)
        {
            return v.VisitSingleArrayAggregate(this, o);
        }

        public Expression E;
    }
}

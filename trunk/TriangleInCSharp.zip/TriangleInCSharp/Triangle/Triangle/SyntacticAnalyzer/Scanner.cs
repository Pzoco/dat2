﻿using System;
using System.Text;

namespace Tools.Triangle.SyntacticAnalyzer
{
    public sealed class Scanner
    {

        private SourceFile sourceFile;
        private bool debug;

        private char currentChar;
        private StringBuilder currentSpelling;
        private bool currentlyScanningToken;

        private bool IsLetter(char c)
        {
            return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
        }

        private bool IsDigit(char c)
        {
            return (c >= '0' && c <= '9');
        }

        // isOperator returns true iff the given character is an operator character.

        private bool IsOperator(char c)
        {
            return (c == '+' || c == '-' || c == '*' || c == '/' ||
                c == '=' || c == '<' || c == '>' || c == '\\' ||
                c == '&' || c == '@' || c == '%' || c == '^' ||
                c == '?');
        }


        ///////////////////////////////////////////////////////////////////////////////

        public Scanner(SourceFile source)
        {
            sourceFile = source;
            currentChar = sourceFile.GetSource();
            debug = false;
        }

        public void EnableDebugging()
        {
            debug = true;
        }

        // takeIt appends the current character to the current token, and gets
        // the next character from the source program.

        private void TakeIt()
        {
            if (currentlyScanningToken)
                currentSpelling.Append(currentChar);
            currentChar = sourceFile.GetSource();
        }

        // scanSeparator skips a single separator.

        private void ScanSeparator()
        {
            switch (currentChar)
            {
                case '!':
                    {
                        TakeIt();
                        while ((currentChar != SourceFile.EOL) && (currentChar != SourceFile.EOT))
                            TakeIt();
                        if (currentChar == SourceFile.EOL)
                            TakeIt();
                    }
                    break;

                case ' ':
                case '\n':
                case '\r':
                case '\t':
                    TakeIt();
                    break;
            }
        }

        private int ScanToken()
        {

            switch (currentChar)
            {

                case 'a':
                case 'b':
                case 'c':
                case 'd':
                case 'e':
                case 'f':
                case 'g':
                case 'h':
                case 'i':
                case 'j':
                case 'k':
                case 'l':
                case 'm':
                case 'n':
                case 'o':
                case 'p':
                case 'q':
                case 'r':
                case 's':
                case 't':
                case 'u':
                case 'v':
                case 'w':
                case 'x':
                case 'y':
                case 'z':
                case 'A':
                case 'B':
                case 'C':
                case 'D':
                case 'E':
                case 'F':
                case 'G':
                case 'H':
                case 'I':
                case 'J':
                case 'K':
                case 'L':
                case 'M':
                case 'N':
                case 'O':
                case 'P':
                case 'Q':
                case 'R':
                case 'S':
                case 'T':
                case 'U':
                case 'V':
                case 'W':
                case 'X':
                case 'Y':
                case 'Z':
                    TakeIt();
                    while (IsLetter(currentChar) || IsDigit(currentChar))
                        TakeIt();
                    return (int)Token.Tokens.IDENTIFIER;

                case '0':
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                    TakeIt();
                    while (IsDigit(currentChar))
                        TakeIt();
                    return (int)Token.Tokens.INTLITERAL;

                case '+':
                case '-':
                case '*':
                case '/':
                case '=':
                case '<':
                case '>':
                case '\\':
                case '&':
                case '@':
                case '%':
                case '^':
                case '?':
                    TakeIt();
                    while (IsOperator(currentChar))
                        TakeIt();
                    return (int)Token.Tokens.OPERATOR;

                case '\'':
                    TakeIt();
                    TakeIt(); // the quoted character
                    if (currentChar == '\'')
                    {
                        TakeIt();
                        return (int)Token.Tokens.CHARLITERAL;
                    }
                    else
                        return (int)Token.Tokens.ERROR;

                case '.':
                    TakeIt();
                    return (int)Token.Tokens.DOT;

                case ':':
                    TakeIt();
                    if (currentChar == '=')
                    {
                        TakeIt();
                        return (int)Token.Tokens.BECOMES;
                    }
                    else
                        return (int)Token.Tokens.COLON;

                case ';':
                    TakeIt();
                    return (int)Token.Tokens.SEMICOLON;

                case ',':
                    TakeIt();
                    return (int)Token.Tokens.COMMA;

                case '~':
                    TakeIt();
                    return (int)Token.Tokens.IS;

                case '(':
                    TakeIt();
                    return (int)Token.Tokens.LPAREN;

                case ')':
                    TakeIt();
                    return (int)Token.Tokens.RPAREN;

                case '[':
                    TakeIt();
                    return (int)Token.Tokens.LBRACKET;

                case ']':
                    TakeIt();
                    return (int)Token.Tokens.RBRACKET;

                case '{':
                    TakeIt();
                    return (int)Token.Tokens.LCURLY;

                case '}':
                    TakeIt();
                    return (int)Token.Tokens.RCURLY;

                case SourceFile.EOT:
                    return (int)Token.Tokens.EOT;

                default:
                    TakeIt();
                    return (int)Token.Tokens.ERROR;
            }
        }

        public Token Scan()
        {
            Token tok;
            SourcePosition pos;
            int kind;

            currentlyScanningToken = false;
            while (currentChar == '!'
                   || currentChar == ' '
                   || currentChar == '\n'
                   || currentChar == '\r'
                   || currentChar == '\t')
                ScanSeparator();

            currentlyScanningToken = true;
            currentSpelling = new StringBuilder("");
            pos = new SourcePosition();
            pos.start = sourceFile.GetCurrentLine();

            kind = ScanToken();

            pos.finish = sourceFile.GetCurrentLine();
            tok = new Token(kind, currentSpelling.ToString(), pos);
            if (debug)
                Console.WriteLine(tok);
            return tok;
        }
    }
}

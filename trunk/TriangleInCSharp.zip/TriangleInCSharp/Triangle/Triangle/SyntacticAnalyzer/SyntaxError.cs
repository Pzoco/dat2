﻿using System;

namespace Tools.Triangle.SyntacticAnalyzer
{
    class SyntaxError : Exception
    {

        public SyntaxError()
            : base()
        {

        }

        SyntaxError(String s)
            : base(s)
        {

        }

    }

}

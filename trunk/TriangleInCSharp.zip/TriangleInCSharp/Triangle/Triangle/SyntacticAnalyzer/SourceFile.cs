﻿using System;

namespace Tools.Triangle.SyntacticAnalyzer
{
    public class SourceFile
    {
        public const char EOL = '\n';
        public const char EOT = '\u0000';

        System.IO.FileInfo sourceFile;
        System.IO.StreamReader source;
        int currentLine;

        public SourceFile(String filename)
        {
            try
            {
                sourceFile = new System.IO.FileInfo(filename);
                source = sourceFile.OpenText();
                currentLine = 1;
            }
            catch (System.IO.IOException s)
            {
                sourceFile = null;
                source = null;
                currentLine = 0;
            }
        }

        internal char GetSource()
        {
            try
            {
                int c = source.Read();

                if (c == -1)
                {
                    c = EOT;
                }
                else if (c == EOL)
                {
                    currentLine++;
                }
                return (char)c;
            }
            catch (System.IO.IOException s)
            {
                return EOT;
            }
        }

        internal int GetCurrentLine()
        {
            return currentLine;
        }
    }
}
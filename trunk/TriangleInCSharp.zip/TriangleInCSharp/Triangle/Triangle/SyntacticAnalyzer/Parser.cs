﻿using System;
using Tools.Triangle;
using Tools.Triangle.AbstractSyntaxTrees;

namespace Tools.Triangle.SyntacticAnalyzer
{
    public class Parser
    {
        private Scanner lexicalAnalyser;
        private ErrorReporter errorReporter;
        private Token currentToken;
        private SourcePosition previousTokenPosition;

        public Parser(Scanner lexer, ErrorReporter reporter)
        {
            lexicalAnalyser = lexer;
            errorReporter = reporter;
            previousTokenPosition = new SourcePosition();
        }

        // accept checks whether the current token matches tokenExpected.
        // If so, fetches the next token.
        // If not, reports a syntactic error.

        void Accept(int tokenExpected)
        {
            if (currentToken.kind == tokenExpected)
            {
                previousTokenPosition = currentToken.position;
                currentToken = lexicalAnalyser.Scan();
            }
            else
            {
                SyntacticError("\"%\" expected here", Token.Spell(tokenExpected));
            }
        }

        void AcceptIt()
        {
            previousTokenPosition = currentToken.position;
            currentToken = lexicalAnalyser.Scan();
        }

        // start records the position of the start of a phrase.
        // This is defined to be the position of the first
        // character of the first token of the phrase.

        void Start(SourcePosition position)
        {
            position.start = currentToken.position.start;
        }

        // finish records the position of the end of a phrase.
        // This is defined to be the position of the last
        // character of the last token of the phrase.

        void Finish(SourcePosition position)
        {
            position.finish = previousTokenPosition.finish;
        }
        void SyntacticError(String messageTemplate, String tokenQuoted)
        {
            SourcePosition pos = currentToken.position;
            errorReporter.ReportError(messageTemplate, tokenQuoted, pos);
            throw (new SyntaxError());
        }

        ///////////////////////////////////////////////////////////////////////////////
        //
        // PROGRAMS
        //
        ///////////////////////////////////////////////////////////////////////////////

        public Program ParseProgram()
        {
            Program programAST = null;

            previousTokenPosition.start = 0;
            previousTokenPosition.finish = 0;
            currentToken = lexicalAnalyser.Scan();

            try
            {
                Command cAST = ParseCommand();
                programAST = new Program(cAST, previousTokenPosition);
                if (currentToken.kind != (int)Token.Tokens.EOT)
                {
                    SyntacticError("\"%\" not expected after end of program",
                      currentToken.spelling);
                }
            }
            catch (SyntaxError s) { return null; }
            return programAST;
        }

        ///////////////////////////////////////////////////////////////////////////////
        //
        // LITERALS
        //
        ///////////////////////////////////////////////////////////////////////////////

        // parseIntegerLiteral parses an integer-literal, and constructs
        // a leaf AST to represent it.

        IntegerLiteral ParseIntegerLiteral()
        {
            IntegerLiteral IL = null;

            if (currentToken.kind == (int)Token.Tokens.INTLITERAL)
            {
                previousTokenPosition = currentToken.position;
                String spelling = currentToken.spelling;
                IL = new IntegerLiteral(spelling, previousTokenPosition);
                currentToken = lexicalAnalyser.Scan();
            }
            else
            {
                IL = null;
                SyntacticError("integer literal expected here", "");
            }
            return IL;
        }

        // parseCharacterLiteral parses a character-literal, and constructs a leaf
        // AST to represent it.

        CharacterLiteral ParseCharacterLiteral()
        {
            CharacterLiteral CL = null;

            if (currentToken.kind == (int)Token.Tokens.CHARLITERAL)
            {
                previousTokenPosition = currentToken.position;
                String spelling = currentToken.spelling;
                CL = new CharacterLiteral(spelling, previousTokenPosition);
                currentToken = lexicalAnalyser.Scan();
            }
            else
            {
                CL = null;
                SyntacticError("character literal expected here", "");
            }
            return CL;
        }

        // parseIdentifier parses an identifier, and constructs a leaf AST to
        // represent it.

        Identifier ParseIdentifier()
        {
            Identifier I = null;

            if (currentToken.kind == (int)Token.Tokens.IDENTIFIER)
            {
                previousTokenPosition = currentToken.position;
                String spelling = currentToken.spelling;
                I = new Identifier(spelling, previousTokenPosition);
                currentToken = lexicalAnalyser.Scan();
            }
            else
            {
                I = null;
                SyntacticError("identifier expected here", "");
            }
            return I;
        }

        // parseOperator parses an operator, and constructs a leaf AST to
        // represent it.

        Operator ParseOperator()
        {
            Operator O = null;

            if (currentToken.kind == (int)Token.Tokens.OPERATOR)
            {
                previousTokenPosition = currentToken.position;
                String spelling = currentToken.spelling;
                O = new Operator(spelling, previousTokenPosition);
                currentToken = lexicalAnalyser.Scan();
            }
            else
            {
                O = null;
                SyntacticError("operator expected here", "");
            }
            return O;
        }

        ///////////////////////////////////////////////////////////////////////////////
        //
        // COMMANDS
        //
        ///////////////////////////////////////////////////////////////////////////////

        // parseCommand parses the command, and constructs an AST
        // to represent its phrase structure.

        Command ParseCommand()
        {
            Command commandAST = null; // in case there's a syntactic error

            SourcePosition commandPos = new SourcePosition();

            Start(commandPos);
            commandAST = ParseSingleCommand();
            while (currentToken.kind == (int)Token.Tokens.SEMICOLON)
            {
                AcceptIt();
                Command c2AST = ParseSingleCommand();
                Finish(commandPos);
                commandAST = new SequentialCommand(commandAST, c2AST, commandPos);
            }
            return commandAST;
        }

        Command ParseSingleCommand()
        {
            Command commandAST = null; // in case there's a syntactic error

            SourcePosition commandPos = new SourcePosition();
            Start(commandPos);

            switch ((Token.Tokens)currentToken.kind)
            {

                case Token.Tokens.IDENTIFIER:
                    {
                        Identifier iAST = ParseIdentifier();
                        if (currentToken.kind == (int)Token.Tokens.LPAREN)
                        {
                            AcceptIt();
                            ActualParameterSequence apsAST = ParseActualParameterSequence();
                            Accept((int)Token.Tokens.RPAREN);
                            Finish(commandPos);
                            commandAST = new CallCommand(iAST, apsAST, commandPos);

                        }
                        else
                        {

                            Vname vAST = ParseRestOfVname(iAST);
                            Accept((int)Token.Tokens.BECOMES);
                            Expression eAST = ParseExpression();
                            Finish(commandPos);
                            commandAST = new AssignCommand(vAST, eAST, commandPos);
                        }
                    }
                    break;

                case Token.Tokens.BEGIN:
                    AcceptIt();
                    commandAST = ParseCommand();
                    Accept((int)Token.Tokens.END);
                    break;

                case Token.Tokens.LET:
                    {
                        AcceptIt();
                        Declaration dAST = ParseDeclaration();
                        Accept((int)Token.Tokens.IN);
                        Command cAST = ParseSingleCommand();
                        Finish(commandPos);
                        commandAST = new LetCommand(dAST, cAST, commandPos);
                    }
                    break;

                case Token.Tokens.IF:
                    {
                        AcceptIt();
                        Expression eAST = ParseExpression();
                        Accept((int)Token.Tokens.THEN);
                        Command c1AST = ParseSingleCommand();
                        Accept((int)Token.Tokens.ELSE);
                        Command c2AST = ParseSingleCommand();
                        Finish(commandPos);
                        commandAST = new IfCommand(eAST, c1AST, c2AST, commandPos);
                    }
                    break;

                case Token.Tokens.WHILE:
                    {
                        AcceptIt();
                        Expression eAST = ParseExpression();
                        Accept((int)Token.Tokens.DO);
                        Command cAST = ParseSingleCommand();
                        Finish(commandPos);
                        commandAST = new WhileCommand(eAST, cAST, commandPos);
                    }
                    break;

                case Token.Tokens.SEMICOLON:
                case Token.Tokens.END:
                case Token.Tokens.ELSE:
                case Token.Tokens.IN:
                case Token.Tokens.EOT:

                    Finish(commandPos);
                    commandAST = new EmptyCommand(commandPos);
                    break;

                default:
                    SyntacticError("\"%\" cannot start a command",
                      currentToken.spelling);
                    break;

            }

            return commandAST;
        }

        ///////////////////////////////////////////////////////////////////////////////
        //
        // EXPRESSIONS
        //
        ///////////////////////////////////////////////////////////////////////////////

        Expression ParseExpression()
        {
            Expression expressionAST = null; // in case there's a syntactic error

            SourcePosition expressionPos = new SourcePosition();

            Start(expressionPos);

            switch ((Token.Tokens)currentToken.kind)
            {

                case Token.Tokens.LET:
                    {
                        AcceptIt();
                        Declaration dAST = ParseDeclaration();
                        Accept((int)Token.Tokens.IN);
                        Expression eAST = ParseExpression();
                        Finish(expressionPos);
                        expressionAST = new LetExpression(dAST, eAST, expressionPos);
                    }
                    break;

                case Token.Tokens.IF:
                    {
                        AcceptIt();
                        Expression e1AST = ParseExpression();
                        Accept((int)Token.Tokens.THEN);
                        Expression e2AST = ParseExpression();
                        Accept((int)Token.Tokens.ELSE);
                        Expression e3AST = ParseExpression();
                        Finish(expressionPos);
                        expressionAST = new IfExpression(e1AST, e2AST, e3AST, expressionPos);
                    }
                    break;

                default:
                    expressionAST = ParseSecondaryExpression();
                    break;
            }
            return expressionAST;
        }

        Expression ParseSecondaryExpression()
        {
            Expression expressionAST = null; // in case there's a syntactic error

            SourcePosition expressionPos = new SourcePosition();
            Start(expressionPos);

            expressionAST = ParsePrimaryExpression();
            while (currentToken.kind == (int)Token.Tokens.OPERATOR)
            {
                Operator opAST = ParseOperator();
                Expression e2AST = ParsePrimaryExpression();
                expressionAST = new BinaryExpression(expressionAST, opAST, e2AST,
                  expressionPos);
            }
            return expressionAST;
        }

        Expression ParsePrimaryExpression()
        {
            Expression expressionAST = null; // in case there's a syntactic error

            SourcePosition expressionPos = new SourcePosition();
            Start(expressionPos);

            switch ((Token.Tokens)currentToken.kind)
            {

                case Token.Tokens.INTLITERAL:
                    {
                        IntegerLiteral ilAST = ParseIntegerLiteral();
                        Finish(expressionPos);
                        expressionAST = new IntegerExpression(ilAST, expressionPos);
                    }
                    break;

                case Token.Tokens.CHARLITERAL:
                    {
                        CharacterLiteral clAST = ParseCharacterLiteral();
                        Finish(expressionPos);
                        expressionAST = new CharacterExpression(clAST, expressionPos);
                    }
                    break;

                case Token.Tokens.LBRACKET:
                    {
                        AcceptIt();
                        ArrayAggregate aaAST = ParseArrayAggregate();
                        Accept((int)Token.Tokens.RBRACKET);
                        Finish(expressionPos);
                        expressionAST = new ArrayExpression(aaAST, expressionPos);
                    }
                    break;

                case Token.Tokens.LCURLY:
                    {
                        AcceptIt();
                        RecordAggregate raAST = ParseRecordAggregate();
                        Accept((int)Token.Tokens.RCURLY);
                        Finish(expressionPos);
                        expressionAST = new RecordExpression(raAST, expressionPos);
                    }
                    break;

                case Token.Tokens.IDENTIFIER:
                    {
                        Identifier iAST = ParseIdentifier();
                        if (currentToken.kind == (int)Token.Tokens.LPAREN)
                        {
                            AcceptIt();
                            ActualParameterSequence apsAST = ParseActualParameterSequence();
                            Accept((int)Token.Tokens.RPAREN);
                            Finish(expressionPos);
                            expressionAST = new CallExpression(iAST, apsAST, expressionPos);

                        }
                        else
                        {
                            Vname vAST = ParseRestOfVname(iAST);
                            Finish(expressionPos);
                            expressionAST = new VnameExpression(vAST, expressionPos);
                        }
                    }
                    break;

                case Token.Tokens.OPERATOR:
                    {
                        Operator opAST = ParseOperator();
                        Expression eAST = ParsePrimaryExpression();
                        Finish(expressionPos);
                        expressionAST = new UnaryExpression(opAST, eAST, expressionPos);
                    }
                    break;

                case Token.Tokens.LPAREN:
                    AcceptIt();
                    expressionAST = ParseExpression();
                    Accept((int)Token.Tokens.RPAREN);
                    break;

                default:
                    SyntacticError("\"%\" cannot start an expression",
                      currentToken.spelling);
                    break;

            }
            return expressionAST;
        }

        RecordAggregate ParseRecordAggregate()
        {
            RecordAggregate aggregateAST = null; // in case there's a syntactic error

            SourcePosition aggregatePos = new SourcePosition();
            Start(aggregatePos);

            Identifier iAST = ParseIdentifier();
            Accept((int)Token.Tokens.IS);
            Expression eAST = ParseExpression();

            if (currentToken.kind == (int)Token.Tokens.COMMA)
            {
                AcceptIt();
                RecordAggregate aAST = ParseRecordAggregate();
                Finish(aggregatePos);
                aggregateAST = new MultipleRecordAggregate(iAST, eAST, aAST, aggregatePos);
            }
            else
            {
                Finish(aggregatePos);
                aggregateAST = new SingleRecordAggregate(iAST, eAST, aggregatePos);
            }
            return aggregateAST;
        }

        ArrayAggregate ParseArrayAggregate()
        {
            ArrayAggregate aggregateAST = null; // in case there's a syntactic error

            SourcePosition aggregatePos = new SourcePosition();
            Start(aggregatePos);

            Expression eAST = ParseExpression();
            if (currentToken.kind == (int)Token.Tokens.COMMA)
            {
                AcceptIt();
                ArrayAggregate aAST = ParseArrayAggregate();
                Finish(aggregatePos);
                aggregateAST = new MultipleArrayAggregate(eAST, aAST, aggregatePos);
            }
            else
            {
                Finish(aggregatePos);
                aggregateAST = new SingleArrayAggregate(eAST, aggregatePos);
            }
            return aggregateAST;
        }

        ///////////////////////////////////////////////////////////////////////////////
        //
        // VALUE-OR-VARIABLE NAMES
        //
        ///////////////////////////////////////////////////////////////////////////////

        Vname ParseVname()
        {
            Vname vnameAST = null; // in case there's a syntactic error
            Identifier iAST = ParseIdentifier();
            vnameAST = ParseRestOfVname(iAST);
            return vnameAST;
        }

        Vname ParseRestOfVname(Identifier identifierAST)
        {
            SourcePosition vnamePos = new SourcePosition();
            vnamePos = identifierAST.position;
            Vname vAST = new SimpleVname(identifierAST, vnamePos);

            while (currentToken.kind == (int)Token.Tokens.DOT ||
                   currentToken.kind == (int)Token.Tokens.LBRACKET)
            {

                if (currentToken.kind == (int)Token.Tokens.DOT)
                {
                    AcceptIt();
                    Identifier iAST = ParseIdentifier();
                    vAST = new DotVname(vAST, iAST, vnamePos);
                }
                else
                {
                    AcceptIt();
                    Expression eAST = ParseExpression();
                    Accept((int)Token.Tokens.RBRACKET);
                    Finish(vnamePos);
                    vAST = new SubscriptVname(vAST, eAST, vnamePos);
                }
            }
            return vAST;
        }

        ///////////////////////////////////////////////////////////////////////////////
        //
        // DECLARATIONS
        //
        ///////////////////////////////////////////////////////////////////////////////

        Declaration ParseDeclaration()
        {
            Declaration declarationAST = null; // in case there's a syntactic error

            SourcePosition declarationPos = new SourcePosition();
            Start(declarationPos);
            declarationAST = ParseSingleDeclaration();
            while (currentToken.kind == (int)Token.Tokens.SEMICOLON)
            {
                AcceptIt();
                Declaration d2AST = ParseSingleDeclaration();
                Finish(declarationPos);
                declarationAST = new SequentialDeclaration(declarationAST, d2AST,
                  declarationPos);
            }
            return declarationAST;
        }

        Declaration ParseSingleDeclaration()
        {
            Declaration declarationAST = null; // in case there's a syntactic error

            SourcePosition declarationPos = new SourcePosition();
            Start(declarationPos);

            switch ((Token.Tokens)currentToken.kind)
            {

                case Token.Tokens.CONST:
                    {
                        AcceptIt();
                        Identifier iAST = ParseIdentifier();
                        Accept((int)Token.Tokens.IS);
                        Expression eAST = ParseExpression();
                        Finish(declarationPos);
                        declarationAST = new ConstDeclaration(iAST, eAST, declarationPos);
                    }
                    break;

                case Token.Tokens.VAR:
                    {
                        AcceptIt();
                        Identifier iAST = ParseIdentifier();
                        Accept((int)Token.Tokens.COLON);
                        TypeDenoter tAST = ParseTypeDenoter();
                        Finish(declarationPos);
                        declarationAST = new VarDeclaration(iAST, tAST, declarationPos);
                    }
                    break;

                case Token.Tokens.PROC:
                    {
                        AcceptIt();
                        Identifier iAST = ParseIdentifier();
                        Accept((int)Token.Tokens.LPAREN);
                        FormalParameterSequence fpsAST = ParseFormalParameterSequence();
                        Accept((int)Token.Tokens.RPAREN);
                        Accept((int)Token.Tokens.IS);
                        Command cAST = ParseSingleCommand();
                        Finish(declarationPos);
                        declarationAST = new ProcDeclaration(iAST, fpsAST, cAST, declarationPos);
                    }
                    break;

                case Token.Tokens.FUNC:
                    {
                        AcceptIt();
                        Identifier iAST = ParseIdentifier();
                        Accept((int)Token.Tokens.LPAREN);
                        FormalParameterSequence fpsAST = ParseFormalParameterSequence();
                        Accept((int)Token.Tokens.RPAREN);
                        Accept((int)Token.Tokens.COLON);
                        TypeDenoter tAST = ParseTypeDenoter();
                        Accept((int)Token.Tokens.IS);
                        Expression eAST = ParseExpression();
                        Finish(declarationPos);
                        declarationAST = new FuncDeclaration(iAST, fpsAST, tAST, eAST,
                          declarationPos);
                    }
                    break;

                case Token.Tokens.TYPE:
                    {
                        AcceptIt();
                        Identifier iAST = ParseIdentifier();
                        Accept((int)Token.Tokens.IS);
                        TypeDenoter tAST = ParseTypeDenoter();
                        Finish(declarationPos);
                        declarationAST = new TypeDeclaration(iAST, tAST, declarationPos);
                    }
                    break;

                default:
                    SyntacticError("\"%\" cannot start a declaration",
                      currentToken.spelling);
                    break;

            }
            return declarationAST;
        }

        ///////////////////////////////////////////////////////////////////////////////
        //
        // PARAMETERS
        //
        ///////////////////////////////////////////////////////////////////////////////

        FormalParameterSequence ParseFormalParameterSequence()
        {
            FormalParameterSequence formalsAST;

            SourcePosition formalsPos = new SourcePosition();

            Start(formalsPos);
            if (currentToken.kind == (int)Token.Tokens.RPAREN)
            {
                Finish(formalsPos);
                formalsAST = new EmptyFormalParameterSequence(formalsPos);

            }
            else
            {
                formalsAST = ParseProperFormalParameterSequence();
            }
            return formalsAST;
        }

        FormalParameterSequence ParseProperFormalParameterSequence()
        {
            FormalParameterSequence formalsAST = null; // in case there's a syntactic error;

            SourcePosition formalsPos = new SourcePosition();
            Start(formalsPos);
            FormalParameter fpAST = ParseFormalParameter();
            if (currentToken.kind == (int)Token.Tokens.COMMA)
            {
                AcceptIt();
                FormalParameterSequence fpsAST = ParseProperFormalParameterSequence();
                Finish(formalsPos);
                formalsAST = new MultipleFormalParameterSequence(fpAST, fpsAST,
                  formalsPos);

            }
            else
            {
                Finish(formalsPos);
                formalsAST = new SingleFormalParameterSequence(fpAST, formalsPos);
            }
            return formalsAST;
        }

        FormalParameter ParseFormalParameter()
        {
            FormalParameter formalAST = null; // in case there's a syntactic error;

            SourcePosition formalPos = new SourcePosition();
            Start(formalPos);

            switch ((Token.Tokens)currentToken.kind)
            {

                case Token.Tokens.IDENTIFIER:
                    {
                        Identifier iAST = ParseIdentifier();
                        Accept((int)Token.Tokens.COLON);
                        TypeDenoter tAST = ParseTypeDenoter();
                        Finish(formalPos);
                        formalAST = new ConstFormalParameter(iAST, tAST, formalPos);
                    }
                    break;

                case Token.Tokens.VAR:
                    {
                        AcceptIt();
                        Identifier iAST = ParseIdentifier();
                        Accept((int)Token.Tokens.COLON);
                        TypeDenoter tAST = ParseTypeDenoter();
                        Finish(formalPos);
                        formalAST = new VarFormalParameter(iAST, tAST, formalPos);
                    }
                    break;

                case Token.Tokens.PROC:
                    {
                        AcceptIt();
                        Identifier iAST = ParseIdentifier();
                        Accept((int)Token.Tokens.LPAREN);
                        FormalParameterSequence fpsAST = ParseFormalParameterSequence();
                        Accept((int)Token.Tokens.RPAREN);
                        Finish(formalPos);
                        formalAST = new ProcFormalParameter(iAST, fpsAST, formalPos);
                    }
                    break;

                case Token.Tokens.FUNC:
                    {
                        AcceptIt();
                        Identifier iAST = ParseIdentifier();
                        Accept((int)Token.Tokens.LPAREN);
                        FormalParameterSequence fpsAST = ParseFormalParameterSequence();
                        Accept((int)Token.Tokens.RPAREN);
                        Accept((int)Token.Tokens.COLON);
                        TypeDenoter tAST = ParseTypeDenoter();
                        Finish(formalPos);
                        formalAST = new FuncFormalParameter(iAST, fpsAST, tAST, formalPos);
                    }
                    break;

                default:
                    SyntacticError("\"%\" cannot start a formal parameter",
                      currentToken.spelling);
                    break;

            }
            return formalAST;
        }

        ActualParameterSequence ParseActualParameterSequence()
        {
            ActualParameterSequence actualsAST;

            SourcePosition actualsPos = new SourcePosition();

            Start(actualsPos);
            if (currentToken.kind == (int)Token.Tokens.RPAREN)
            {
                Finish(actualsPos);
                actualsAST = new EmptyActualParameterSequence(actualsPos);

            }
            else
            {
                actualsAST = ParseProperActualParameterSequence();
            }
            return actualsAST;
        }

        ActualParameterSequence ParseProperActualParameterSequence()
        {
            ActualParameterSequence actualsAST = null; // in case there's a syntactic error

            SourcePosition actualsPos = new SourcePosition();

            Start(actualsPos);
            ActualParameter apAST = ParseActualParameter();
            if (currentToken.kind == (int)Token.Tokens.COMMA)
            {
                AcceptIt();
                ActualParameterSequence apsAST = ParseProperActualParameterSequence();
                Finish(actualsPos);
                actualsAST = new MultipleActualParameterSequence(apAST, apsAST,
                  actualsPos);
            }
            else
            {
                Finish(actualsPos);
                actualsAST = new SingleActualParameterSequence(apAST, actualsPos);
            }
            return actualsAST;
        }

        ActualParameter ParseActualParameter()
        {
            ActualParameter actualAST = null; // in case there's a syntactic error

            SourcePosition actualPos = new SourcePosition();

            Start(actualPos);

            switch ((Token.Tokens)currentToken.kind)
            {

                case Token.Tokens.IDENTIFIER:
                case Token.Tokens.INTLITERAL:
                case Token.Tokens.CHARLITERAL:
                case Token.Tokens.OPERATOR:
                case Token.Tokens.LET:
                case Token.Tokens.IF:
                case Token.Tokens.LPAREN:
                case Token.Tokens.LBRACKET:
                case Token.Tokens.LCURLY:
                    {
                        Expression eAST = ParseExpression();
                        Finish(actualPos);
                        actualAST = new ConstActualParameter(eAST, actualPos);
                    }
                    break;

                case Token.Tokens.VAR:
                    {
                        AcceptIt();
                        Vname vAST = ParseVname();
                        Finish(actualPos);
                        actualAST = new VarActualParameter(vAST, actualPos);
                    }
                    break;

                case Token.Tokens.PROC:
                    {
                        AcceptIt();
                        Identifier iAST = ParseIdentifier();
                        Finish(actualPos);
                        actualAST = new ProcActualParameter(iAST, actualPos);
                    }
                    break;

                case Token.Tokens.FUNC:
                    {
                        AcceptIt();
                        Identifier iAST = ParseIdentifier();
                        Finish(actualPos);
                        actualAST = new FuncActualParameter(iAST, actualPos);
                    }
                    break;

                default:
                    SyntacticError("\"%\" cannot start an actual parameter",
                      currentToken.spelling);
                    break;

            }
            return actualAST;
        }

        ///////////////////////////////////////////////////////////////////////////////
        //
        // TYPE-DENOTERS
        //
        ///////////////////////////////////////////////////////////////////////////////

        TypeDenoter ParseTypeDenoter()
        {
            TypeDenoter typeAST = null; // in case there's a syntactic error
            SourcePosition typePos = new SourcePosition();

            Start(typePos);

            switch ((Token.Tokens)currentToken.kind)
            {

                case Token.Tokens.IDENTIFIER:
                    {
                        Identifier iAST = ParseIdentifier();
                        Finish(typePos);
                        typeAST = new SimpleTypeDenoter(iAST, typePos);
                    }
                    break;

                case Token.Tokens.ARRAY:
                    {
                        AcceptIt();
                        IntegerLiteral ilAST = ParseIntegerLiteral();
                        Accept((int)Token.Tokens.OF);
                        TypeDenoter tAST = ParseTypeDenoter();
                        Finish(typePos);
                        typeAST = new ArrayTypeDenoter(ilAST, tAST, typePos);
                    }
                    break;

                case Token.Tokens.RECORD:
                    {
                        AcceptIt();
                        FieldTypeDenoter fAST = ParseFieldTypeDenoter();
                        Accept((int)Token.Tokens.END);
                        Finish(typePos);
                        typeAST = new RecordTypeDenoter(fAST, typePos);
                    }
                    break;

                default:
                    SyntacticError("\"%\" cannot start a type denoter",
                      currentToken.spelling);
                    break;

            }
            return typeAST;
        }

        FieldTypeDenoter ParseFieldTypeDenoter()
        {
            FieldTypeDenoter fieldAST = null; // in case there's a syntactic error

            SourcePosition fieldPos = new SourcePosition();

            Start(fieldPos);
            Identifier iAST = ParseIdentifier();
            Accept((int)Token.Tokens.COLON);
            TypeDenoter tAST = ParseTypeDenoter();
            if (currentToken.kind == (int)Token.Tokens.COMMA)
            {
                AcceptIt();
                FieldTypeDenoter fAST = ParseFieldTypeDenoter();
                Finish(fieldPos);
                fieldAST = new MultipleFieldTypeDenoter(iAST, tAST, fAST, fieldPos);
            }
            else
            {
                Finish(fieldPos);
                fieldAST = new SingleFieldTypeDenoter(iAST, tAST, fieldPos);
            }
            return fieldAST;
        }
    }
}

﻿using System;

namespace Tools.Triangle.SyntacticAnalyzer
{
    public sealed class Token
    {
        public int kind;
        public String spelling;
        public SourcePosition position;

        public Token(int kind, String spelling, SourcePosition position)
        {

            if (kind == (int)Token.Tokens.IDENTIFIER)
            {
                int currentKind = firstReservedWord;
                bool searching = true;

                while (searching)
                {
                    int comparison = tokenTable[currentKind].CompareTo(spelling);
                    if (comparison == 0)
                    {
                        this.kind = currentKind;
                        searching = false;
                    }
                    else if (comparison > 0 || currentKind == lastReservedWord)
                    {
                        this.kind = (int)Token.Tokens.IDENTIFIER;
                        searching = false;
                    }
                    else
                    {
                        currentKind++;
                    }
                }
            }
            else
                this.kind = kind;

            this.spelling = spelling;
            this.position = position;

        }

        public static String Spell(int kind)
        {
            return tokenTable[kind];
        }

        public override String ToString()
        {
            return "Kind=" + kind + ", spelling=" + spelling +
              ", position=" + position;
        }

        // Token classes...

        public enum Tokens
        {
            // literals, identifiers, operators...
            INTLITERAL = 0,
            CHARLITERAL = 1,
            IDENTIFIER = 2,
            OPERATOR = 3,

            // reserved words - must be in alphabetical order...
            ARRAY = 4,
            BEGIN = 5,
            CONST = 6,
            DO = 7,
            ELSE = 8,
            END = 9,
            FUNC = 10,
            IF = 11,
            IN = 12,
            LET = 13,
            OF = 14,
            PROC = 15,
            RECORD = 16,
            THEN = 17,
            TYPE = 18,
            VAR = 19,
            WHILE = 20,

            // punctuation...
            DOT = 21,
            COLON = 22,
            SEMICOLON = 23,
            COMMA = 24,
            BECOMES = 25,
            IS = 26,

            // brackets...
            LPAREN = 27,
            RPAREN = 28,
            LBRACKET = 29,
            RBRACKET = 30,
            LCURLY = 31,
            RCURLY = 32,

            // special tokens...
            EOT = 33,
            ERROR = 34
        }

        private static String[] tokenTable = new String[] {
            "<int>",
            "<char>",
            "<identifier>",
            "<operator>",
            "array",
            "begin",
            "const",
            "do",
            "else",
            "end",
            "func",
            "if",
            "in",
            "let",
            "of",
            "proc",
            "record",
            "then",
            "type",
            "var",
            "while",
            ".",
            ":",
            ";",
            ",",
            ":=",
            "~",
            "(",
            ")",
            "[",
            "]",
            "{",
            "}",
            "",
            "<error>"
        };

        private readonly static int firstReservedWord = (int)Token.Tokens.ARRAY,
                      lastReservedWord = (int)Token.Tokens.WHILE;

    }
}

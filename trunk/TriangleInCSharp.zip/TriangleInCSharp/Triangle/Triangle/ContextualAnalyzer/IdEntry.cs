﻿using System;
using Tools.Triangle.AbstractSyntaxTrees;

namespace Tools.Triangle.ContextualAnalyzer
{
    public class IdEntry
    {
        internal String id;
        internal Declaration attr;
        internal int level;
        internal IdEntry previous;

        internal IdEntry(String id, Declaration attr, int level, IdEntry previous)
        {
            this.id = id;
            this.attr = attr;
            this.level = level;
            this.previous = previous;
        }
    }
}

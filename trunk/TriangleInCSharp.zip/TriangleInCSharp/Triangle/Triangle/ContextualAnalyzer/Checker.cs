﻿using System;
using Tools.Triangle.TreeDrawer;
using Tools.Triangle.AbstractSyntaxTrees;
using Tools.Triangle.SyntacticAnalyzer;

namespace Tools.Triangle.ContextualAnalyzer
{
    public sealed class Checker : Visitor
    {
        // Commands

        // Always returns null. Does not use the given object.

        public Object VisitAssignCommand(AssignCommand ast, Object o)
        {
            TypeDenoter vType = (TypeDenoter)ast.V.Visit(this, null);
            TypeDenoter eType = (TypeDenoter)ast.E.Visit(this, null);
            if (!ast.V.variable)
                reporter.ReportError("LHS of assignment is not a variable", "", ast.V.position);
            if (!eType.Equals(vType))
                reporter.ReportError("assignment incompatibilty", "", ast.position);
            return null;
        }


        public Object VisitCallCommand(CallCommand ast, Object o)
        {

            Declaration binding = (Declaration)ast.I.Visit(this, null);
            if (binding == null)
                ReportUndeclared(ast.I);
            else if (binding is ProcDeclaration)
            {
                ast.APS.Visit(this, ((ProcDeclaration)binding).FPS);
            }
            else if (binding is ProcFormalParameter)
            {
                ast.APS.Visit(this, ((ProcFormalParameter)binding).FPS);
            }
            else
                reporter.ReportError("\"%\" is not a procedure identifier", ast.I.spelling, ast.I.position);
            return null;
        }

        public Object VisitEmptyCommand(EmptyCommand ast, Object o)
        {
            return null;
        }

        public Object VisitIfCommand(IfCommand ast, Object o)
        {
            TypeDenoter eType = (TypeDenoter)ast.E.Visit(this, null);
            if (!eType.Equals(StdEnvironment.booleanType))
                reporter.ReportError("Boolean expression expected here", "", ast.E.position);
            ast.C1.Visit(this, null);
            ast.C2.Visit(this, null);
            return null;
        }

        public Object VisitLetCommand(LetCommand ast, Object o)
        {
            idTable.OpenScope();
            ast.D.Visit(this, null);
            ast.C.Visit(this, null);
            idTable.CloseScope();
            return null;
        }

        public Object VisitSequentialCommand(SequentialCommand ast, Object o)
        {
            ast.C1.Visit(this, null);
            ast.C2.Visit(this, null);
            return null;
        }

        public Object VisitWhileCommand(WhileCommand ast, Object o)
        {
            TypeDenoter eType = (TypeDenoter)ast.E.Visit(this, null);
            if (!eType.Equals(StdEnvironment.booleanType))
                reporter.ReportError("Boolean expression expected here", "", ast.E.position);
            ast.C.Visit(this, null);
            return null;
        }

        // Expressions

        // Returns the TypeDenoter denoting the type of the expression. Does
        // not use the given object.

        public Object VisitArrayExpression(ArrayExpression ast, Object o)
        {
            TypeDenoter elemType = (TypeDenoter)ast.AA.Visit(this, null);
            IntegerLiteral il = new IntegerLiteral(ast.AA.elemCount.ToString(), ast.position);
            ast.type = new ArrayTypeDenoter(il, elemType, ast.position);
            return ast.type;
        }

        public Object VisitBinaryExpression(BinaryExpression ast, Object o)
        {
            TypeDenoter e1Type = (TypeDenoter)ast.E1.Visit(this, null);
            TypeDenoter e2Type = (TypeDenoter)ast.E2.Visit(this, null);
            Declaration binding = (Declaration)ast.O.Visit(this, null);

            if (binding == null)
                ReportUndeclared(ast.O);
            else
            {
                if (!(binding is BinaryOperatorDeclaration))
                    reporter.ReportError("\"%\" is not a binary operator", ast.O.spelling, ast.O.position);
                BinaryOperatorDeclaration bbinding = (BinaryOperatorDeclaration)binding;
                if (bbinding.ARG1 == StdEnvironment.anyType)
                {
                    // this operator must be "=" or "\="
                    if (!e1Type.Equals(e2Type))
                        reporter.ReportError("incompatible argument types for \"%\"", ast.O.spelling, ast.position);
                }
                else if (!e1Type.Equals(bbinding.ARG1))
                    reporter.ReportError("wrong argument type for \"%\"", ast.O.spelling, ast.E1.position);
                else if (!e2Type.Equals(bbinding.ARG2))
                    reporter.ReportError("wrong argument type for \"%\"", ast.O.spelling, ast.E2.position);
                ast.type = bbinding.RES;
            }
            return ast.type;
        }

        public Object VisitCallExpression(CallExpression ast, Object o)
        {
            Declaration binding = (Declaration)ast.I.Visit(this, null);
            if (binding == null)
            {
                ReportUndeclared(ast.I);
                ast.type = StdEnvironment.errorType;
            }
            else if (binding is FuncDeclaration)
            {
                ast.APS.Visit(this, ((FuncDeclaration)binding).FPS);
                ast.type = ((FuncDeclaration)binding).T;
            }
            else if (binding is FuncFormalParameter)
            {
                ast.APS.Visit(this, ((FuncFormalParameter)binding).FPS);
                ast.type = ((FuncFormalParameter)binding).T;
            }
            else
                reporter.ReportError("\"%\" is not a function identifier", ast.I.spelling, ast.I.position);
            return ast.type;
        }

        public Object VisitCharacterExpression(CharacterExpression ast, Object o)
        {
            ast.type = StdEnvironment.charType;
            return ast.type;
        }

        public Object VisitEmptyExpression(EmptyExpression ast, Object o)
        {
            ast.type = null;
            return ast.type;
        }

        public Object VisitIfExpression(IfExpression ast, Object o)
        {
            TypeDenoter e1Type = (TypeDenoter)ast.E1.Visit(this, null);
            if (!e1Type.Equals(StdEnvironment.booleanType))
                reporter.ReportError("Boolean expression expected here", "", ast.E1.position);
            TypeDenoter e2Type = (TypeDenoter)ast.E2.Visit(this, null);
            TypeDenoter e3Type = (TypeDenoter)ast.E3.Visit(this, null);
            if (!e2Type.Equals(e3Type))
                reporter.ReportError("incompatible limbs in if-expression", "", ast.position);
            ast.type = e2Type;
            return ast.type;
        }

        public Object VisitIntegerExpression(IntegerExpression ast, Object o)
        {
            ast.type = StdEnvironment.integerType;
            return ast.type;
        }

        public Object VisitLetExpression(LetExpression ast, Object o)
        {
            idTable.OpenScope();
            ast.D.Visit(this, null);
            ast.type = (TypeDenoter)ast.E.Visit(this, null);
            idTable.CloseScope();
            return ast.type;
        }

        public Object VisitRecordExpression(RecordExpression ast, Object o)
        {
            FieldTypeDenoter rType = (FieldTypeDenoter)ast.RA.Visit(this, null);
            ast.type = new RecordTypeDenoter(rType, ast.position);
            return ast.type;
        }

        public Object VisitUnaryExpression(UnaryExpression ast, Object o)
        {
            TypeDenoter eType = (TypeDenoter)ast.E.Visit(this, null);
            Declaration binding = (Declaration)ast.O.Visit(this, null);
            if (binding == null)
            {
                ReportUndeclared(ast.O);
                ast.type = StdEnvironment.errorType;
            }
            else if (!(binding is UnaryOperatorDeclaration))
                reporter.ReportError("\"%\" is not a unary operator", ast.O.spelling, ast.O.position);
            else
            {
                UnaryOperatorDeclaration ubinding = (UnaryOperatorDeclaration)binding;
                if (!eType.Equals(ubinding.ARG))
                    reporter.ReportError("wrong argument type for \"%\"", ast.O.spelling, ast.O.position);
                ast.type = ubinding.RES;
            }
            return ast.type;
        }

        public Object VisitVnameExpression(VnameExpression ast, Object o)
        {
            ast.type = (TypeDenoter)ast.V.Visit(this, null);
            return ast.type;
        }

        // Declarations

        // Always returns null. Does not use the given object.
        public Object VisitBinaryOperatorDeclaration(BinaryOperatorDeclaration ast, Object o)
        {
            return null;
        }

        public Object VisitConstDeclaration(ConstDeclaration ast, Object o)
        {
            TypeDenoter eType = (TypeDenoter)ast.E.Visit(this, null);
            idTable.Enter(ast.I.spelling, ast);
            if (ast.duplicated)
                reporter.ReportError("identifier \"%\" already declared", ast.I.spelling, ast.position);
            return null;
        }

        public Object VisitFuncDeclaration(FuncDeclaration ast, Object o)
        {
            ast.T = (TypeDenoter)ast.T.Visit(this, null);
            idTable.Enter(ast.I.spelling, ast); // permits recursion
            if (ast.duplicated)
                reporter.ReportError("identifier \"%\" already declared", ast.I.spelling, ast.position);
            idTable.OpenScope();
            ast.FPS.Visit(this, null);
            TypeDenoter eType = (TypeDenoter)ast.E.Visit(this, null);
            idTable.CloseScope();
            if (!ast.T.Equals(eType))
                reporter.ReportError("body of function \"%\" has wrong type", ast.I.spelling, ast.E.position);
            return null;
        }

        public Object VisitProcDeclaration(ProcDeclaration ast, Object o)
        {
            idTable.Enter(ast.I.spelling, ast); // permits recursion
            if (ast.duplicated)
                reporter.ReportError("identifier \"%\" already declared", ast.I.spelling, ast.position);
            idTable.OpenScope();
            ast.FPS.Visit(this, null);
            ast.C.Visit(this, null);
            idTable.CloseScope();
            return null;
        }

        public Object VisitSequentialDeclaration(SequentialDeclaration ast, Object o)
        {
            ast.D1.Visit(this, null);
            ast.D2.Visit(this, null);
            return null;
        }

        public Object VisitTypeDeclaration(TypeDeclaration ast, Object o)
        {
            ast.T = (TypeDenoter)ast.T.Visit(this, null);
            idTable.Enter(ast.I.spelling, ast);
            if (ast.duplicated)
                reporter.ReportError("identifier \"%\" already declared", ast.I.spelling, ast.position);
            return null;
        }

        public Object VisitUnaryOperatorDeclaration(UnaryOperatorDeclaration ast, Object o)
        {
            return null;
        }

        public Object VisitVarDeclaration(VarDeclaration ast, Object o)
        {
            ast.T = (TypeDenoter)ast.T.Visit(this, null);
            idTable.Enter(ast.I.spelling, ast);
            if (ast.duplicated)
                reporter.ReportError("identifier \"%\" already declared", ast.I.spelling, ast.position);

            return null;
        }

        // Array Aggregates

        // Returns the TypeDenoter for the Array Aggregate. Does not use the
        // given object.

        public Object VisitMultipleArrayAggregate(MultipleArrayAggregate ast, Object o)
        {
            TypeDenoter eType = (TypeDenoter)ast.E.Visit(this, null);
            TypeDenoter elemType = (TypeDenoter)ast.AA.Visit(this, null);
            ast.elemCount = ast.AA.elemCount + 1;
            if (!eType.Equals(elemType))
                reporter.ReportError("incompatible array-aggregate element", "", ast.E.position);
            return elemType;
        }

        public Object VisitSingleArrayAggregate(SingleArrayAggregate ast, Object o)
        {
            TypeDenoter elemType = (TypeDenoter)ast.E.Visit(this, null);
            ast.elemCount = 1;
            return elemType;
        }

        // Record Aggregates

        // Returns the TypeDenoter for the Record Aggregate. Does not use the
        // given object.

        public Object VisitMultipleRecordAggregate(MultipleRecordAggregate ast, Object o)
        {
            TypeDenoter eType = (TypeDenoter)ast.E.Visit(this, null);
            FieldTypeDenoter rType = (FieldTypeDenoter)ast.RA.Visit(this, null);
            TypeDenoter fType = CheckFieldIdentifier(rType, ast.I);
            if (fType != StdEnvironment.errorType)
                reporter.ReportError("duplicate field \"%\" in record", ast.I.spelling, ast.I.position);
            ast.type = new MultipleFieldTypeDenoter(ast.I, eType, rType, ast.position);
            return ast.type;
        }

        public Object VisitSingleRecordAggregate(SingleRecordAggregate ast, Object o)
        {
            TypeDenoter eType = (TypeDenoter)ast.E.Visit(this, null);
            ast.type = new SingleFieldTypeDenoter(ast.I, eType, ast.position);
            return ast.type;
        }

        // Formal Parameters

        // Always returns null. Does not use the given object.

        public Object VisitConstFormalParameter(ConstFormalParameter ast, Object o)
        {
            ast.T = (TypeDenoter)ast.T.Visit(this, null);
            idTable.Enter(ast.I.spelling, ast);
            if (ast.duplicated)
                reporter.ReportError("duplicated formal parameter \"%\"", ast.I.spelling, ast.position);
            return null;
        }

        public Object VisitFuncFormalParameter(FuncFormalParameter ast, Object o)
        {
            idTable.OpenScope();
            ast.FPS.Visit(this, null);
            idTable.CloseScope();
            ast.T = (TypeDenoter)ast.T.Visit(this, null);
            idTable.Enter(ast.I.spelling, ast);
            if (ast.duplicated)
                reporter.ReportError("duplicated formal parameter \"%\"", ast.I.spelling, ast.position);
            return null;
        }

        public Object VisitProcFormalParameter(ProcFormalParameter ast, Object o)
        {
            idTable.OpenScope();
            ast.FPS.Visit(this, null);
            idTable.CloseScope();
            idTable.Enter(ast.I.spelling, ast);
            if (ast.duplicated)
                reporter.ReportError("duplicated formal parameter \"%\"", ast.I.spelling, ast.position);
            return null;
        }

        public Object VisitVarFormalParameter(VarFormalParameter ast, Object o)
        {
            ast.T = (TypeDenoter)ast.T.Visit(this, null);
            idTable.Enter(ast.I.spelling, ast);
            if (ast.duplicated)
                reporter.ReportError("duplicated formal parameter \"%\"", ast.I.spelling, ast.position);
            return null;
        }

        public Object VisitEmptyFormalParameterSequence(EmptyFormalParameterSequence ast, Object o)
        {
            return null;
        }

        public Object VisitMultipleFormalParameterSequence(MultipleFormalParameterSequence ast, Object o)
        {
            ast.FP.Visit(this, null);
            ast.FPS.Visit(this, null);
            return null;
        }

        public Object VisitSingleFormalParameterSequence(SingleFormalParameterSequence ast, Object o)
        {
            ast.FP.Visit(this, null);
            return null;
        }

        // Actual Parameters

        // Always returns null. Uses the given FormalParameter.

        public Object VisitConstActualParameter(ConstActualParameter ast, Object o)
        {
            FormalParameter fp = (FormalParameter)o;
            TypeDenoter eType = (TypeDenoter)ast.E.Visit(this, null);

            if (!(fp is ConstFormalParameter))
                reporter.ReportError("const actual parameter not expected here", "", ast.position);
            else if (!eType.Equals(((ConstFormalParameter)fp).T))
                reporter.ReportError("wrong type for const actual parameter", "", ast.E.position);
            return null;
        }

        public Object VisitFuncActualParameter(FuncActualParameter ast, Object o)
        {
            FormalParameter fp = (FormalParameter)o;

            Declaration binding = (Declaration)ast.I.Visit(this, null);
            if (binding == null)
                ReportUndeclared(ast.I);
            else if (!(binding is FuncDeclaration || binding is FuncFormalParameter))
                reporter.ReportError("\"%\" is not a function identifier", ast.I.spelling, ast.I.position);
            else if (!(fp is FuncFormalParameter))
                reporter.ReportError("func actual parameter not expected here", "", ast.position);
            else
            {
                FormalParameterSequence FPS = null;
                TypeDenoter T = null;
                if (binding is FuncDeclaration)
                {
                    FPS = ((FuncDeclaration)binding).FPS;
                    T = ((FuncDeclaration)binding).T;
                }
                else
                {
                    FPS = ((FuncFormalParameter)binding).FPS;
                    T = ((FuncFormalParameter)binding).T;
                }
                if (!FPS.Equals(((FuncFormalParameter)fp).FPS))
                    reporter.ReportError("wrong signature for function \"%\"", ast.I.spelling, ast.I.position);
                else if (!T.Equals(((FuncFormalParameter)fp).T))
                    reporter.ReportError("wrong type for function \"%\"", ast.I.spelling, ast.I.position);
            }
            return null;
        }

        public Object VisitProcActualParameter(ProcActualParameter ast, Object o)
        {
            FormalParameter fp = (FormalParameter)o;

            Declaration binding = (Declaration)ast.I.Visit(this, null);
            if (binding == null)
                ReportUndeclared(ast.I);
            else if (!(binding is ProcDeclaration || binding is ProcFormalParameter))
                reporter.ReportError("\"%\" is not a procedure identifier", ast.I.spelling, ast.I.position);
            else if (!(fp is ProcFormalParameter))
                reporter.ReportError("proc actual parameter not expected here", "", ast.position);
            else
            {
                FormalParameterSequence FPS = null;
                if (binding is ProcDeclaration)
                    FPS = ((ProcDeclaration)binding).FPS;
                else
                    FPS = ((ProcFormalParameter)binding).FPS;
                if (!FPS.Equals(((ProcFormalParameter)fp).FPS))
                    reporter.ReportError("wrong signature for procedure \"%\"", ast.I.spelling, ast.I.position);
            }
            return null;
        }

        public Object VisitVarActualParameter(VarActualParameter ast, Object o)
        {
            FormalParameter fp = (FormalParameter)o;

            TypeDenoter vType = (TypeDenoter)ast.V.Visit(this, null);
            if (!ast.V.variable)
                reporter.ReportError("actual parameter is not a variable", "", ast.V.position);
            else if (!(fp is VarFormalParameter))
                reporter.ReportError("var actual parameter not expected here", "", ast.V.position);
            else if (!vType.Equals(((VarFormalParameter)fp).T))
                reporter.ReportError("wrong type for var actual parameter", "", ast.V.position);
            return null;
        }

        public Object VisitEmptyActualParameterSequence(EmptyActualParameterSequence ast, Object o)
        {
            FormalParameterSequence fps = (FormalParameterSequence)o;
            if (!(fps is EmptyFormalParameterSequence))
                reporter.ReportError("too few actual parameters", "", ast.position);
            return null;
        }

        public Object VisitMultipleActualParameterSequence(MultipleActualParameterSequence ast, Object o)
        {
            FormalParameterSequence fps = (FormalParameterSequence)o;
            if (!(fps is MultipleFormalParameterSequence))
                reporter.ReportError("too many actual parameters", "", ast.position);
            else
            {
                ast.AP.Visit(this, ((MultipleFormalParameterSequence)fps).FP);
                ast.APS.Visit(this, ((MultipleFormalParameterSequence)fps).FPS);
            }
            return null;
        }

        public Object VisitSingleActualParameterSequence(SingleActualParameterSequence ast, Object o)
        {
            FormalParameterSequence fps = (FormalParameterSequence)o;
            if (!(fps is SingleFormalParameterSequence))
                reporter.ReportError("incorrect number of actual parameters", "", ast.position);
            else
            {
                ast.AP.Visit(this, ((SingleFormalParameterSequence)fps).FP);
            }
            return null;
        }

        // Type Denoters

        // Returns the expanded version of the TypeDenoter. Does not
        // use the given object.

        public Object VisitAnyTypeDenoter(AnyTypeDenoter ast, Object o)
        {
            return StdEnvironment.anyType;
        }

        public Object VisitArrayTypeDenoter(ArrayTypeDenoter ast, Object o)
        {
            ast.T = (TypeDenoter)ast.T.Visit(this, null);
            if ((int.Parse(ast.IL.spelling)) == 0)
                reporter.ReportError("arrays must not be empty", "", ast.IL.position);
            return ast;
        }

        public Object VisitBoolTypeDenoter(BoolTypeDenoter ast, Object o)
        {
            return StdEnvironment.booleanType;
        }

        public Object VisitCharTypeDenoter(CharTypeDenoter ast, Object o)
        {
            return StdEnvironment.charType;
        }

        public Object VisitErrorTypeDenoter(ErrorTypeDenoter ast, Object o)
        {
            return StdEnvironment.errorType;
        }

        public Object VisitSimpleTypeDenoter(SimpleTypeDenoter ast, Object o)
        {
            Declaration binding = (Declaration)ast.I.Visit(this, null);
            if (binding == null)
            {
                ReportUndeclared(ast.I);
                return StdEnvironment.errorType;
            }
            else if (!(binding is TypeDeclaration))
            {
                reporter.ReportError("\"%\" is not a type identifier", ast.I.spelling, ast.I.position);
                return StdEnvironment.errorType;
            }
            return ((TypeDeclaration)binding).T;
        }

        public Object VisitIntTypeDenoter(IntTypeDenoter ast, Object o)
        {
            return StdEnvironment.integerType;
        }

        public Object VisitRecordTypeDenoter(RecordTypeDenoter ast, Object o)
        {
            ast.FT = (FieldTypeDenoter)ast.FT.Visit(this, null);
            return ast;
        }

        public Object VisitMultipleFieldTypeDenoter(MultipleFieldTypeDenoter ast, Object o)
        {
            ast.T = (TypeDenoter)ast.T.Visit(this, null);
            ast.FT.Visit(this, null);
            return ast;
        }

        public Object VisitSingleFieldTypeDenoter(SingleFieldTypeDenoter ast, Object o)
        {
            ast.T = (TypeDenoter)ast.T.Visit(this, null);
            return ast;
        }

        // Literals, Identifiers and Operators
        public Object VisitCharacterLiteral(CharacterLiteral CL, Object o)
        {
            return StdEnvironment.charType;
        }

        public Object VisitIdentifier(Identifier I, Object o)
        {
            Declaration binding = idTable.Retrieve(I.spelling);
            if (binding != null)
                I.decl = binding;
            return binding;
        }

        public Object VisitIntegerLiteral(IntegerLiteral IL, Object o)
        {
            return StdEnvironment.integerType;
        }

        public Object VisitOperator(Operator O, Object o)
        {
            Declaration binding = idTable.Retrieve(O.spelling);
            if (binding != null)
                O.decl = binding;
            return binding;
        }

        // Value-or-variable names

        // Determines the address of a named object (constant or variable).
        // This consists of a base object, to which 0 or more field-selection
        // or array-indexing operations may be applied (if it is a record or
        // array).  As much as possible of the address computation is done at
        // compile-time. Code is generated only when necessary to evaluate
        // index expressions at run-time.
        // currentLevel is the routine level where the v-name occurs.
        // frameSize is the anticipated size of the local stack frame when
        // the object is addressed at run-time.
        // It returns the description of the base object.
        // offset is set to the total of any field offsets (plus any offsets
        // due to index expressions that happen to be literals).
        // indexed is set to true iff there are any index expressions (other
        // than literals). In that case code is generated to compute the
        // offset due to these indexing operations at run-time.

        // Returns the TypeDenoter of the Vname. Does not use the
        // given object.

        public Object VisitDotVname(DotVname ast, Object o)
        {
            ast.type = null;
            TypeDenoter vType = (TypeDenoter)ast.V.Visit(this, null);
            ast.variable = ast.V.variable;
            if (!(vType is RecordTypeDenoter))
                reporter.ReportError("record expected here", "", ast.V.position);
            else
            {
                ast.type = CheckFieldIdentifier(((RecordTypeDenoter)vType).FT, ast.I);
                if (ast.type == StdEnvironment.errorType)
                    reporter.ReportError("no field \"%\" in this record type", ast.I.spelling, ast.I.position);
            }
            return ast.type;
        }

        public Object VisitSimpleVname(SimpleVname ast, Object o)
        {
            ast.variable = false;
            ast.type = StdEnvironment.errorType;
            Declaration binding = (Declaration)ast.I.Visit(this, null);
            if (binding == null)
                ReportUndeclared(ast.I);
            else
                if (binding is ConstDeclaration)
                {
                    ast.type = ((ConstDeclaration)binding).E.type;
                    ast.variable = false;
                }
                else if (binding is VarDeclaration)
                {
                    ast.type = ((VarDeclaration)binding).T;
                    ast.variable = true;
                }
                else if (binding is ConstFormalParameter)
                {
                    ast.type = ((ConstFormalParameter)binding).T;
                    ast.variable = false;
                }
                else if (binding is VarFormalParameter)
                {
                    ast.type = ((VarFormalParameter)binding).T;
                    ast.variable = true;
                }
                else
                    reporter.ReportError("\"%\" is not a const or var identifier", ast.I.spelling, ast.I.position);
            return ast.type;
        }

        public Object VisitSubscriptVname(SubscriptVname ast, Object o)
        {
            TypeDenoter vType = (TypeDenoter)ast.V.Visit(this, null);
            ast.variable = ast.V.variable;
            TypeDenoter eType = (TypeDenoter)ast.E.Visit(this, null);
            if (vType != StdEnvironment.errorType)
            {
                if (!(vType is ArrayTypeDenoter))
                    reporter.ReportError("array expected here", "", ast.V.position);
                else
                {
                    if (!eType.Equals(StdEnvironment.integerType))
                        reporter.ReportError("Integer expression expected here", "",
                              ast.E.position);
                    ast.type = ((ArrayTypeDenoter)vType).T;
                }
            }
            return ast.type;
        }

        // Programs

        public Object VisitProgram(Program ast, Object o)
        {
            ast.C.Visit(this, null);
            return null;
        }

        // Checks whether the source program, represented by its AST, satisfies the
        // language's scope rules and type rules.
        // Also decorates the AST as follows:
        //  (a) Each applied occurrence of an identifier or operator is linked to
        //      the corresponding declaration of that identifier or operator.
        //  (b) Each expression and value-or-variable-name is decorated by its type.
        //  (c) Each type identifier is replaced by the type it denotes.
        // Types are represented by small ASTs.

        public void Check(Program ast)
        {
            ast.Visit(this, null);
        }

        /////////////////////////////////////////////////////////////////////////////

        public Checker(ErrorReporter reporter)
        {
            this.reporter = reporter;
            this.idTable = new IdentificationTable();
            EstablishStdEnvironment();
        }

        private IdentificationTable idTable;
        private static SourcePosition dummyPos = new SourcePosition();
        private ErrorReporter reporter;

        // Reports that the identifier or operator used at a leaf of the AST
        // has not been declared.

        private void ReportUndeclared(Terminal leaf)
        {
            reporter.ReportError("\"%\" is not declared", leaf.spelling, leaf.position);
        }


        private static TypeDenoter CheckFieldIdentifier(FieldTypeDenoter ast, Identifier I)
        {
            if (ast is MultipleFieldTypeDenoter)
            {
                MultipleFieldTypeDenoter ft = (MultipleFieldTypeDenoter)ast;
                if (ft.I.spelling.CompareTo(I.spelling) == 0)
                {
                    I.decl = ast;
                    return ft.T;
                }
                else
                {
                    return CheckFieldIdentifier(ft.FT, I);
                }
            }
            else if (ast is SingleFieldTypeDenoter)
            {
                SingleFieldTypeDenoter ft = (SingleFieldTypeDenoter)ast;
                if (ft.I.spelling.CompareTo(I.spelling) == 0)
                {
                    I.decl = ast;
                    return ft.T;
                }
            }
            return StdEnvironment.errorType;
        }


        // Creates a small AST to represent the "declaration" of a standard
        // type, and enters it in the identification table.

        private TypeDeclaration DeclareStdType(String id, TypeDenoter typedenoter)
        {
            TypeDeclaration binding;

            binding = new TypeDeclaration(new Identifier(id, dummyPos), typedenoter, dummyPos);
            idTable.Enter(id, binding);
            return binding;
        }

        // Creates a small AST to represent the "declaration" of a standard
        // type, and enters it in the identification table.

        private ConstDeclaration DeclareStdConst(String id, TypeDenoter constType)
        {
            IntegerExpression constExpr;
            ConstDeclaration binding;

            // constExpr used only as a placeholder for constType
            constExpr = new IntegerExpression(null, dummyPos);
            constExpr.type = constType;
            binding = new ConstDeclaration(new Identifier(id, dummyPos), constExpr, dummyPos);
            idTable.Enter(id, binding);
            return binding;
        }

        // Creates a small AST to represent the "declaration" of a standard
        // type, and enters it in the identification table.

        private ProcDeclaration DeclareStdProc(String id, FormalParameterSequence fps)
        {
            ProcDeclaration binding;

            binding = new ProcDeclaration(new Identifier(id, dummyPos), fps, new EmptyCommand(dummyPos), dummyPos);
            idTable.Enter(id, binding);
            return binding;
        }

        // Creates a small AST to represent the "declaration" of a standard
        // type, and enters it in the identification table.

        private FuncDeclaration DeclareStdFunc(String id, FormalParameterSequence fps, TypeDenoter resultType)
        {
            FuncDeclaration binding;

            binding = new FuncDeclaration(new Identifier(id, dummyPos), fps, resultType, new EmptyExpression(dummyPos), dummyPos);
            idTable.Enter(id, binding);
            return binding;
        }

        // Creates a small AST to represent the "declaration" of a
        // unary operator, and enters it in the identification table.
        // This "declaration" summarises the operator's type info.

        private UnaryOperatorDeclaration DeclareStdUnaryOp(String op, TypeDenoter argType, TypeDenoter resultType)
        {
            UnaryOperatorDeclaration binding;

            binding = new UnaryOperatorDeclaration(new Operator(op, dummyPos), argType, resultType, dummyPos);
            idTable.Enter(op, binding);
            return binding;
        }

        // Creates a small AST to represent the "declaration" of a
        // binary operator, and enters it in the identification table.
        // This "declaration" summarises the operator's type info.

        private BinaryOperatorDeclaration DeclareStdBinaryOp(String op, TypeDenoter arg1Type, TypeDenoter arg2type, TypeDenoter resultType)
        {
            BinaryOperatorDeclaration binding;

            binding = new BinaryOperatorDeclaration(new Operator(op, dummyPos), arg1Type, arg2type, resultType, dummyPos);
            idTable.Enter(op, binding);
            return binding;
        }

        // Creates small ASTs to represent the standard types.
        // Creates small ASTs to represent "declarations" of standard types,
        // constants, procedures, functions, and operators.
        // Enters these "declarations" in the identification table.

        private readonly static Identifier dummyI = new Identifier("", dummyPos);

        private void EstablishStdEnvironment()
        {
            // idTable.startIdentification();
            StdEnvironment.booleanType = new BoolTypeDenoter(dummyPos);
            StdEnvironment.integerType = new IntTypeDenoter(dummyPos);
            StdEnvironment.charType = new CharTypeDenoter(dummyPos);
            StdEnvironment.anyType = new AnyTypeDenoter(dummyPos);
            StdEnvironment.errorType = new ErrorTypeDenoter(dummyPos);

            StdEnvironment.booleanDecl = DeclareStdType("Boolean", StdEnvironment.booleanType);
            StdEnvironment.falseDecl = DeclareStdConst("false", StdEnvironment.booleanType);
            StdEnvironment.trueDecl = DeclareStdConst("true", StdEnvironment.booleanType);
            StdEnvironment.notDecl = DeclareStdUnaryOp("\\", StdEnvironment.booleanType, StdEnvironment.booleanType);
            StdEnvironment.andDecl = DeclareStdBinaryOp("/\\", StdEnvironment.booleanType, StdEnvironment.booleanType, StdEnvironment.booleanType);
            StdEnvironment.orDecl = DeclareStdBinaryOp("\\/", StdEnvironment.booleanType, StdEnvironment.booleanType, StdEnvironment.booleanType);

            StdEnvironment.integerDecl = DeclareStdType("Integer", StdEnvironment.integerType);
            StdEnvironment.maxintDecl = DeclareStdConst("maxint", StdEnvironment.integerType);
            StdEnvironment.addDecl = DeclareStdBinaryOp("+", StdEnvironment.integerType, StdEnvironment.integerType, StdEnvironment.integerType);
            StdEnvironment.subtractDecl = DeclareStdBinaryOp("-", StdEnvironment.integerType, StdEnvironment.integerType, StdEnvironment.integerType);
            StdEnvironment.multiplyDecl = DeclareStdBinaryOp("*", StdEnvironment.integerType, StdEnvironment.integerType, StdEnvironment.integerType);
            StdEnvironment.divideDecl = DeclareStdBinaryOp("/", StdEnvironment.integerType, StdEnvironment.integerType, StdEnvironment.integerType);
            StdEnvironment.moduloDecl = DeclareStdBinaryOp("//", StdEnvironment.integerType, StdEnvironment.integerType, StdEnvironment.integerType);
            StdEnvironment.lessDecl = DeclareStdBinaryOp("<", StdEnvironment.integerType, StdEnvironment.integerType, StdEnvironment.booleanType);
            StdEnvironment.notgreaterDecl = DeclareStdBinaryOp("<=", StdEnvironment.integerType, StdEnvironment.integerType, StdEnvironment.booleanType);
            StdEnvironment.greaterDecl = DeclareStdBinaryOp(">", StdEnvironment.integerType, StdEnvironment.integerType, StdEnvironment.booleanType);
            StdEnvironment.notlessDecl = DeclareStdBinaryOp(">=", StdEnvironment.integerType, StdEnvironment.integerType, StdEnvironment.booleanType);

            StdEnvironment.charDecl = DeclareStdType("Char", StdEnvironment.charType);
            StdEnvironment.chrDecl = DeclareStdFunc("chr", new SingleFormalParameterSequence(new ConstFormalParameter(dummyI, StdEnvironment.integerType, dummyPos), dummyPos), StdEnvironment.charType);
            StdEnvironment.ordDecl = DeclareStdFunc("ord", new SingleFormalParameterSequence(new ConstFormalParameter(dummyI, StdEnvironment.charType, dummyPos), dummyPos), StdEnvironment.integerType);
            StdEnvironment.eofDecl = DeclareStdFunc("eof", new EmptyFormalParameterSequence(dummyPos), StdEnvironment.booleanType);
            StdEnvironment.eolDecl = DeclareStdFunc("eol", new EmptyFormalParameterSequence(dummyPos), StdEnvironment.booleanType);
            StdEnvironment.getDecl = DeclareStdProc("get", new SingleFormalParameterSequence(new VarFormalParameter(dummyI, StdEnvironment.charType, dummyPos), dummyPos));
            StdEnvironment.putDecl = DeclareStdProc("put", new SingleFormalParameterSequence(new ConstFormalParameter(dummyI, StdEnvironment.charType, dummyPos), dummyPos));
            StdEnvironment.getintDecl = DeclareStdProc("getint", new SingleFormalParameterSequence(new VarFormalParameter(dummyI, StdEnvironment.integerType, dummyPos), dummyPos));
            StdEnvironment.putintDecl = DeclareStdProc("putint", new SingleFormalParameterSequence(new ConstFormalParameter(dummyI, StdEnvironment.integerType, dummyPos), dummyPos));
            StdEnvironment.geteolDecl = DeclareStdProc("geteol", new EmptyFormalParameterSequence(dummyPos));
            StdEnvironment.puteolDecl = DeclareStdProc("puteol", new EmptyFormalParameterSequence(dummyPos));
            StdEnvironment.equalDecl = DeclareStdBinaryOp("=", StdEnvironment.anyType, StdEnvironment.anyType, StdEnvironment.booleanType);
            StdEnvironment.unequalDecl = DeclareStdBinaryOp("\\=", StdEnvironment.anyType, StdEnvironment.anyType, StdEnvironment.booleanType);

        }
    }
}
